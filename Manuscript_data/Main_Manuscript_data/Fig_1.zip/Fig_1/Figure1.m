%% Combined Figure 1: (a-c) JPG images + (d) MATLAB plot

base_path = pwd;

figure(1); clf;
set(gcf,'Units','centimeters','Position',[2 2 23 21],'Color','w');

t = tiledlayout(2,2,'TileSpacing','compact','Padding','compact');
la = -0.21;
lb = 1.04;

%% ================= PANEL (a) =================

ax1 = nexttile(1);
img = imread(fullfile(base_path,'Fig1a.jpg'));
imshow(img,'Parent',ax1);
axis(ax1,'image');
axis(ax1,'off');
text(ax1,la,lb,'(a)','Units','normalized','FontSize',22,'FontWeight','normal','HorizontalAlignment','left','VerticalAlignment','top','Clipping','off');

%% ================= PANEL (b) =================

ax2 = nexttile(2);
img = imread(fullfile(base_path,'Fig1b.jpg'));
imshow(img,'Parent',ax2);
axis(ax2,'image');
axis(ax2,'off');
text(ax2,la,lb,'(b)','Units','normalized','FontSize',22,'FontWeight','normal','HorizontalAlignment','left','VerticalAlignment','top','Clipping','off');

%% ================= PANEL (c) =================

ax3 = nexttile(3);
img = imread(fullfile(base_path,'Fig1c.jpg'));
imshow(img,'Parent',ax3);
axis(ax3,'image');
axis(ax3,'off');
text(ax3,la,lb,'(c)','Units','normalized','FontSize',22,'FontWeight','normal','HorizontalAlignment','left','VerticalAlignment','top','Clipping','off');

%% ================= PANEL (d) =================

ax4 = nexttile(4);
hold(ax4,'on');

N = 250;
plot_colors = turbo(N);

for i = 0:N-1
    a0 = readmatrix(fullfile(base_path,'Fig1d',sprintf('dens_prob_%d.csv',i)));
    plot(ax4,a0(:,1),a0(:,2),'-','Color',plot_colors(i+1,:),'LineWidth',2.5);
end

xlabel(ax4,'$\rho_e^l$','FontSize',25,'Interpreter','latex');
ylabel(ax4,'$P(\rho_e^l)$','FontSize',25,'Interpreter','latex');

xlim(ax4,[-0.05 1.05]);
ylim(ax4,[0 17]);
xticks(ax4,[0 0.5 1]);
yticks(ax4,[0 5 10 15]);

ax4.FontSize = 20;
ax4.TickLabelInterpreter = 'latex';
ax4.LineWidth = 2;

axis(ax4,'square');
box(ax4,'on');

%% ================= COLORMAP =================

colormap(ax4,turbo(N));
clim(ax4,[0.5 0.5*25000/60]);

%% ================= COLORBAR =================

cbar = colorbar(ax4);

cbar.FontSize = 20;
cbar.LineWidth = 1;
cbar.TickLabelInterpreter = 'latex';

drawnow;
cbar.Position = [0.926 0.102 0.017 0.397];

t = annotation(gcf,'textbox',[0.98 0.38 0.04 0.18], 'String','$\mathrm{Time~(min)}$', 'Interpreter','latex', 'FontSize',20, 'Rotation',90, 'EdgeColor','none', ...
    'HorizontalAlignment','center','VerticalAlignment','middle');

%% ================= PANEL (d) LABEL =================

text(ax4,la,lb,'(d)','Units','normalized','FontSize',22,'FontWeight','normal','HorizontalAlignment','left','VerticalAlignment','top','Clipping','off');
exportgraphics(gcf, fullfile(pwd, 'Figure1.jpg'),'Resolution',600)