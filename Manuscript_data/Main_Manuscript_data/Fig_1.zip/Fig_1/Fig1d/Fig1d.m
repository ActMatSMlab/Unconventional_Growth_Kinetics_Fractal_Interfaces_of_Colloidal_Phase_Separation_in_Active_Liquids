path = pwd;


N = 250;
plot_colors = turbo(N);

figure(2); clf; hold on

for i = 0:N-1
    a0 = readmatrix(fullfile(path, sprintf('dens_prob_%d.csv',i)));
    plot(a0(:,1),a0(:,2),'-','Color',plot_colors(i+1,:),'LineWidth',4);
end

% Axes
xlabel('$\rho_e^l$','FontSize',30,'Interpreter','latex');
ylabel('$P(\rho_e^l)$','FontSize',30,'Interpreter','latex');
xlim([-0.05 1.15]);
ylim([0 17]);
yticks([0 5 10 15]);
axis square; 
box on

ax = gca;
set(gca,'FontSize',25,'TickLabelInterpreter','latex','LineWidth',3)
ax.Position = [0.15 0.20 0.68 0.75];


% Figure
set(gcf,'Units','centimeters','Position',[2 2 17 15], 'Color','w');


% Colormap and colorbar
colormap(turbo(N));
clim([0.5 0.5*25000/60]);

cbar = colorbar;
cbar.Position = [0.828 0.195 0.026 0.758];
cbar.FontSize = 20;
cbar.LineWidth = 1;
cbar.TickLabelInterpreter = "latex";


t = annotation(gcf,'textbox',[0.86 0.78 0.04 0.18], 'String','$\mathrm{Time~(min)}$', 'Interpreter','latex', 'FontSize',20, 'Rotation',90, 'EdgeColor','none', ...
    'HorizontalAlignment','center','VerticalAlignment','middle');