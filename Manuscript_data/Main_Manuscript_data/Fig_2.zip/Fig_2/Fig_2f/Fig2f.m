clear all
path = pwd;

figure(1); clf, hold on
set(gcf,'Units','centimeters','Position',[2 2 20 15]);

a0 = readmatrix(fullfile(path,'data.dat'));
a1 = readmatrix(fullfile(path,'fitting_line.dat'));


plot(a0(:,1),  a0(:,2), 'bo','markersize',8,'linewidth',3,'DisplayName', '$\rho_g = 0.28, c_b = 5b_0$')
plot(a1(:,1),  a1(:,2), 'r-.','markersize',8,'linewidth',4)


set(gca, 'XScale', 'log')
set(gca, 'YScale', 'log')
legend('',sprintf('$d_f = %.2f \\pm %.2f$',1.52,0.07),'location', 'southeast','interpreter','latex','Box','off')
xlim([3e-3 1e0]);
ylim([1e0 5e4]);
xticks([1e-2 1e-1 1e0])
yticks([1e0 1e2 1e4])

set(gcf,'units','centimeters','position',[0 0 18 15])
set(gca,'FontSize',25);
xlabel('$1\l_b$','FontSize',28,'interpreter','latex')
ylabel('$N_e\l_b$','FontSize',28,'interpreter','latex')
axis square;
box on

grid off
set(gca,'FontSize',25,'TickLabelInterpreter','latex','LineWidth',3)
