clear all
path_main = fullfile(pwd, 'Main');
path1 = pwd;
%% ================= MAIN FIGURE =================
figure(1); clf
set(gcf,'Units','centimeters','Position',[2 2 20 15]);
N = 250;
d1 = dir(fullfile(path_main,'Sq_*.txt'));
N1 = length(d1);

plot_colors = turbo(N);
colormap(turbo(N));

ax1 = axes('Position',[0.15 0.20 0.68 0.70]);
hold(ax1,'on');
ii = 0;
for i = N-N1:N-1
    ii = ii+1;
    a0 = readmatrix(fullfile(path_main,sprintf('Sq_%d.txt',ii)));
    plot(ax1,a0(:,1),a0(:,2),'-','Color',plot_colors(i+1,:),'LineWidth',4);
end

a1 = readmatrix(fullfile(path1,'Avg_Sq.txt'));
a2 = readmatrix(fullfile(path1,'fitted_data.txt'));
a3 = readmatrix(fullfile(path1,'slope_3.0.txt'));
plot(ax1,a1(:,1),a1(:,2),'b-','LineWidth',4);
h1 = plot(ax1,a2(:,1),a2(:,2),'r-.','LineWidth',4);
h2 = plot(ax1,a3(:,1),a3(:,2),'k-','LineWidth',4);

xlabel('$kL_e(t)$','FontSize',33,'interpreter','latex')
ylabel('$S_e(k)/L_e(t)^2$','FontSize',33,'interpreter','latex')
ax1.XScale = 'log';
ax1.YScale = 'log';

xlim(ax1,[0.4 60]);
ylim(ax1,[0.00005 2]);

xticks(ax1,[1e0  1e1 ]);
yticks(ax1,[1e-4 1e-2 1e0]);


ax1.TickLength = [0.015 0.015];
ax1.TickLabelInterpreter = 'latex';

box(ax1,'on');
axis(ax1,'square');

clim(ax1,[0.5 0.5*25000/60]);
set(ax1,'FontSize',25,'TickLabelInterpreter','latex','LineWidth',3)
legend(ax1,[h1 h2], sprintf('$-(d+\\alpha) = %.2f \\pm %.2f$',2.40,0.14), '$-(d+\alpha) = -3.0$', 'Location','southeast', 'Interpreter','latex', 'FontSize',20, 'Box','off');
% Colorbar
cbar = colorbar(ax1);
cbar.Position = [0.76 0.20 0.025 0.705];
cbar.FontSize = 18;
cbar.LineWidth = 0.1;
cbar.TickLabelInterpreter = "latex";

t = annotation(gcf,'textbox',[0.79 0.74 0.04 0.18], 'String','$\mathrm{Time~(min)}$', 'Interpreter','latex', 'FontSize',20, 'Rotation',90, 'EdgeColor','none', ...
    'HorizontalAlignment','center','VerticalAlignment','middle');