%% ============================================================
% FIGURE 2: Combined 2 x 3 tiled figure
% =============================================================
clear
base_path = pwd;

path2b_main = fullfile(base_path,'Fig_2b','Main');
path2b_inset = fullfile(base_path,'Fig_2b','Inset');

path2c = fullfile(base_path,'Fig_2c');

path2d_main = fullfile(base_path,'Fig_2d','Main');
path2d = fullfile(base_path,'Fig_2d');

path2e_main = fullfile(base_path,'Fig_2e','Main');
path2e = fullfile(base_path,'Fig_2e');

path2f = fullfile(base_path,'Fig_2f');

N = 250;
plot_colors = turbo(N);

figure(1); clf;
set(gcf,'Units','centimeters','Position',[0 0 45 20],'Color','w');

tl = tiledlayout(2,3,'TileSpacing','tight','Padding','loose');

la = -0.3;
lb = 1.04;

%% ============================================================
% PANEL (a)
% =============================================================

axa = nexttile(tl,1);

img = imread(fullfile(base_path,'Fig2a.jpg'));
imshow(img,'Parent',axa);

axis(axa,'image');
axis(axa,'off');


%% Panel (a) colorbar
% clim(axa,[-1 1]);
% cbar_a = colorbar(axa);
% cbar_a.FontSize = 14;
% cbar_a.LineWidth = 1;
% cbar_a.TickLabelInterpreter = 'latex';

colormap(axa,turbo(N));
clim(axa,[-1 1]);

cbar_a = colorbar(axa);
% cbar_a.Position = [0.311 0.17 0.012 0.72];
cbar_a.FontSize = 16;
cbar_a.LineWidth = 1;
cbar_a.TickLabelInterpreter = 'latex';
cbar_a.Ticks = [-1  0  1];


text(axa,la,lb,'(a)','Units','normalized','FontSize',20,'FontWeight','normal','HorizontalAlignment','left','VerticalAlignment','top','Clipping','off');


%% ============================================================
% PANEL (b): f_e(x)
% =============================================================

axb = nexttile(tl,2);
hold(axb,'on');

d1 = dir(fullfile(path2b_main,'scaled_*.txt'));
N1 = length(d1);

ii = 0;

for i = N-N1:N-1
    ii = ii+1;
    a0 = readmatrix(fullfile(path2b_main,sprintf('scaled_%d.txt',ii)));
    plot(axb,a0(:,1),a0(:,2),'-','Color',plot_colors(i+1,:),'LineWidth',2.5);
end

xlabel(axb,'$x$','FontSize',22,'Interpreter','latex');
ylabel(axb,'$f_e(x)$','FontSize',22,'Interpreter','latex');

xlim(axb,[-0.1 5]);
ylim(axb,[-0.15 1.05]);

xticks(axb,[0 1 2 3 4]);
yticks(axb,[0 0.5 1]);

set(axb,'FontSize',17,'TickLabelInterpreter','latex','LineWidth',2);

box(axb,'on');
axis(axb,'square');

clim(axb,[0.5 0.5*25000/60]);

%% Panel (b) colorbar

cbar_b = colorbar(axb);
cbar_b.FontSize = 14;
cbar_b.LineWidth = 1;
cbar_b.TickLabelInterpreter = 'latex';



%% Panel (b) inset

drawnow;

posb = axb.Position;

axbin = axes(gcf,'Position',[posb(1)+0.375*posb(3) posb(2)+0.39*posb(4) 0.61*posb(3) 0.59*posb(4)]);
hold(axbin,'on');

d2 = dir(fullfile(path2b_inset,'unscaled_*.txt'));
N2 = length(d2);

ii = 0;

for i = N-N2:N-1
    ii = ii+1;
    a0 = readmatrix(fullfile(path2b_inset,sprintf('unscaled_%d.txt',ii)));
    plot(axbin,a0(:,1),a0(:,2),'-','Color',plot_colors(i+1,:),'LineWidth',1.5);
end

plot(axbin,[0 33],[0 0],'--k','LineWidth',1);

xlabel(axbin,'$r/\sigma$','FontSize',18,'Interpreter','latex');
ylabel(axbin,'$C_e(r,t)$','FontSize',18,'Interpreter','latex');

xlim(axbin,[-0.1 15]);
ylim(axbin,[-0.2 1.1]);

xticks(axbin,[0 5 10]);
yticks(axbin,[0 0.5 1]);

set(axbin,'FontSize',15,'TickLabelInterpreter','latex','LineWidth',1.5);

box(axbin,'on');
axis(axbin,'square');
uistack(axbin,'top');

text(axb,la,lb,'(b)','Units','normalized','FontSize',20,'FontWeight','normal','HorizontalAlignment','left','VerticalAlignment','top','Clipping','off');


%% ============================================================
% PANEL (c): L_e(t)
% =============================================================

axc = nexttile(tl,3);
hold(axc,'on');

a0 = readmatrix(fullfile(path2c,'main_plot.txt'));
a1 = readmatrix(fullfile(path2c,'slope_0.24.txt'));
a2 = readmatrix(fullfile(path2c,'slope_0.33.txt'));

h0c = plot(axc,a0(:,1),a0(:,2),'bo','MarkerSize',8,'LineWidth',2);
h1c = plot(axc,a1(:,1),a1(:,2),'r-','LineWidth',3);
h2c = plot(axc,a2(:,1),a2(:,2),'k-','LineWidth',3);

axc.XScale = 'log';
axc.YScale = 'log';

xlim(axc,[120 20000]);
ylim(axc,[2 20]);

xticks(axc,[1000 10000]);
yticks(axc,[5 15]);

xlabel(axc,'$t~(\mathrm{sec})$','FontSize',22,'Interpreter','latex');
ylabel(axc,'$L_e(t)/\sigma$','FontSize',22,'Interpreter','latex');

set(axc,'FontSize',17,'TickLabelInterpreter','latex','LineWidth',2);

axis(axc,'square');
box(axc,'on');
grid(axc,'off');

legend(axc,[h0c h1c h2c],'$\rho_e^0=0.28,\,c_e=5b_0$','$1/z=1/4$','$1/z=1/3$','Location','southeast','Interpreter','latex','FontSize',12,'Box','off');

text(axc,la,lb,'(c)','Units','normalized','FontSize',20,'FontWeight','normal','HorizontalAlignment','left','VerticalAlignment','top','Clipping','off');


%% ============================================================
% PANEL (d): 1-f_e(x)
% =============================================================

axd = nexttile(tl,4);
hold(axd,'on');

d1 = dir(fullfile(path2d_main,'gx_*.txt'));
N1 = length(d1);

ii = 0;

for i = N-N1:N-1
    ii = ii+1;
    a0 = readmatrix(fullfile(path2d_main,sprintf('gx_%d.txt',ii)));
    plot(axd,a0(:,1),a0(:,2),'-','Color',plot_colors(i+1,:),'LineWidth',2.5,'HandleVisibility','off');
end

a1 = readmatrix(fullfile(path2d,'Avg_gr.txt'));
a2 = readmatrix(fullfile(path2d,'log_fitting.txt'));
a3 = readmatrix(fullfile(path2d,'log_slope_1.txt'));

plot(axd,a1(:,1),a1(:,2),'b-','LineWidth',2.5,'HandleVisibility','off');

h1d = plot(axd,a2(:,1),a2(:,2),'r-.','LineWidth',2.5);
h2d = plot(axd,a3(:,1),a3(:,2),'k-','LineWidth',2.5);

xlabel(axd,'$x$','FontSize',22,'Interpreter','latex');
ylabel(axd,'$1-f_e(x)$','FontSize',22,'Interpreter','latex');

axd.XScale = 'log';
axd.YScale = 'log';

xlim(axd,[1e-2 10]);
ylim(axd,[0.08 3]);

xticks(axd,[1e-2 1e0]);
yticks(axd,[1e-1 1e0]);

axd.XMinorTick = 'on';
axd.YMinorTick = 'on';
axd.TickLength = [0.015 0.015];

set(axd,'FontSize',17,'TickLabelInterpreter','latex','LineWidth',2);

box(axd,'on');
axis(axd,'square');

clim(axd,[0.5 0.5*25000/60]);

legend(axd,[h1d h2d],sprintf('$\\alpha = %.2f \\pm %.2f$',0.47,0.01),'$\alpha=1$','Location','southeast','Interpreter','latex','FontSize',13,'Box','off');

cbar_d = colorbar(axd);
cbar_d.FontSize = 14;
cbar_d.LineWidth = 1;
cbar_d.TickLabelInterpreter = 'latex';

text(axd,la,lb,'(d)','Units','normalized','FontSize',20,'FontWeight','normal','HorizontalAlignment','left','VerticalAlignment','top','Clipping','off');


%% ============================================================
% PANEL (e): Structure factor
% =============================================================

axe = nexttile(tl,5);
hold(axe,'on');

d1 = dir(fullfile(path2e_main,'Sq_*.txt'));
N1 = length(d1);

ii = 0;

for i = N-N1:N-1
    ii = ii+1;
    a0 = readmatrix(fullfile(path2e_main,sprintf('Sq_%d.txt',ii)));
    plot(axe,a0(:,1),a0(:,2),'-','Color',plot_colors(i+1,:),'LineWidth',2.5,'HandleVisibility','off');
end

a1 = readmatrix(fullfile(path2e,'Avg_Sq.txt'));
a2 = readmatrix(fullfile(path2e,'fitted_data.txt'));
a3 = readmatrix(fullfile(path2e,'slope_3.0.txt'));

plot(axe,a1(:,1),a1(:,2),'b-','LineWidth',2.5,'HandleVisibility','off');

h1e = plot(axe,a2(:,1),a2(:,2),'r-.','LineWidth',2.5);
h2e = plot(axe,a3(:,1),a3(:,2),'k-','LineWidth',2.5);

xlabel(axe,'$kL_e(t)$','FontSize',22,'Interpreter','latex');
ylabel(axe,'$S_e(k)/L_e(t)^2$','FontSize',22,'Interpreter','latex');

axe.XScale = 'log';
axe.YScale = 'log';

xlim(axe,[0.4 60]);
ylim(axe,[0.00005 2]);

xticks(axe,[1e0 1e1]);
yticks(axe,[1e-4 1e-2 1e0]);

axe.XMinorTick = 'on';
axe.YMinorTick = 'on';
axe.TickLength = [0.015 0.015];

set(axe,'FontSize',17,'TickLabelInterpreter','latex','LineWidth',2);

box(axe,'on');
axis(axe,'square');

clim(axe,[0.5 0.5*25000/60]);

legend(axe,[h1e h2e],sprintf('$-(d+\\alpha)=-(%.2f \\pm %.2f)$',2.40,0.14),'$-(d+\alpha)=-3.0$','Location','southwest','Interpreter','latex','FontSize',12,'Box','off');

cbar_e = colorbar(axe);
cbar_e.FontSize = 14;
cbar_e.LineWidth = 1;
cbar_e.TickLabelInterpreter = 'latex';

text(axe,la,lb,'(e)','Units','normalized','FontSize',20,'FontWeight','normal','HorizontalAlignment','left','VerticalAlignment','top','Clipping','off');


%% ============================================================
% PANEL (f): N_e(l_b) versus 1/l_b
% IMPORTANT: replace filenames below with your actual filenames
% =============================================================

axf = nexttile(tl,6);
hold(axf,'on');

a0 = readmatrix(fullfile(path2f,'data.dat'));
a1 = readmatrix(fullfile(path2f,'fitting_line.dat'));

h0f = plot(axf,a0(:,1),a0(:,2),'bo','MarkerSize',8,'LineWidth',2);
h1f = plot(axf,a1(:,1),a1(:,2),'r-.','LineWidth',3);

axf.XScale = 'log';
axf.YScale = 'log';

xlabel(axf,'$1/l_b$','FontSize',22,'Interpreter','latex');
ylabel(axf,'$N_e(l_b)$','FontSize',22,'Interpreter','latex');

xlim(axf, [3e-3 1e0]);
ylim(axf,[1e0 5e4]);
xticks(axf,[1e-2 1e-1 1e0])
yticks(axf,[1e0 1e2 1e4])

set(axf,'FontSize',17,'TickLabelInterpreter','latex','LineWidth',2);

axf.XMinorTick = 'on';
axf.YMinorTick = 'on';
axf.TickLength = [0.015 0.015];

axis(axf,'square');
box(axf,'on');

legend(axf,h1f,sprintf('$d_f=%.2f \\pm %.2f$',1.52,0.07),'Location','southeast','Interpreter','latex','FontSize',12,'Box','off');

text(axf,la,lb,'(f)','Units','normalized','FontSize',20,'FontWeight','normal','HorizontalAlignment','left','VerticalAlignment','top','Clipping','off');


%% ============================================================
% COMMON COLORMAP
% =============================================================

colormap(gcf,turbo(N));


%% ============================================================
% COLORBAR TIME LABELS
% Use independent text so inset/axes do not cover labels
% =============================================================

%% ================= FINAL COLORBAR POSITIONS =================

drawnow;

pa = axa.Position;
pb = axb.Position;
pd = axd.Position;
pe = axe.Position;

cbar_a.Position = [pa(1)+pa(3)+0.0215 pa(2)+0.003 0.010 pa(4)-0.006];
cbar_b.Position = [pb(1)+pb(3)+0.002 pb(2) 0.010 pb(4)];
cbar_d.Position = [pd(1)+pd(3)+0.022 pd(2) 0.010 pd(4)];
cbar_e.Position = [pe(1)+pe(3)+0.002 pe(2) 0.010 pe(4)];

drawnow;

pa = cbar_a.Position;
pb = cbar_b.Position;
pd = cbar_d.Position;
pe = cbar_e.Position;

annotation(gcf,'textbox',[pb(1)+0.016 pb(2)+0.7*pb(4) 0.025 0.30*pb(4)],'String','$\mathrm{Time~(min)}$','Interpreter','latex','FontSize',13,'Rotation',90,'EdgeColor','none','HorizontalAlignment','center','VerticalAlignment','middle');

annotation(gcf,'textbox',[pd(1)+0.016 pd(2)+0.7*pd(4) 0.025 0.30*pd(4)],'String','$\mathrm{Time~(min)}$','Interpreter','latex','FontSize',13,'Rotation',90,'EdgeColor','none','HorizontalAlignment','center','VerticalAlignment','middle');

annotation(gcf,'textbox',[pe(1)+0.016 pe(2)+0.7*pe(4) 0.025 0.30*pe(4)],'String','$\mathrm{Time~(min)}$','Interpreter','latex','FontSize',13,'Rotation',90,'EdgeColor','none','HorizontalAlignment','center','VerticalAlignment','middle');

% uistack(axbin,'top');

exportgraphics(gcf,fullfile(pwd,'Figure2.jpg'),'Resolution',600);