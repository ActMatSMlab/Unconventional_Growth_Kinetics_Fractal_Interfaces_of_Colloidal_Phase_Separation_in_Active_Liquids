clear; clc; close all;

base_path = pwd;
path3a_main = fullfile(base_path,'Fig_3a/scaling_r_by_l');
path3a_inset = fullfile(base_path,'Fig_3a/unscaled_data');
path3b = fullfile(base_path,'Fig_3b/Data');
path3c = fullfile(base_path,'Fig_3c/data');

figure(1); clf;
set(gcf,'Units','centimeters','Position',[2 2 33 11],'Color','w');

% Main panel positions [left bottom width height]
pos_a = [0.06 0.17 0.255 0.72];
pos_b = [0.41 0.17 0.255 0.72];
pos_c = [0.74 0.17 0.255 0.72];

fs_a = 18;
fs_l = 22;

%% ===================== PANEL (a) =====================

N = 20;
plot_colors = turbo(N*10);

axa = axes('Position',pos_a);
hold(axa,'on');

for i = 1:N
    a = readmatrix(fullfile(path3a_main,sprintf('corr_%d.dat',i)));
    plot(axa,a(:,1),a(:,3),'-','Color',plot_colors(i*10,:),'LineWidth',4);
end

xlabel(axa,'$x$','FontSize',fs_l,'Interpreter','latex');
ylabel(axa,'$f(x)$','FontSize',fs_l,'Interpreter','latex');
xlim(axa,[-0.2 20]);
ylim(axa,[-0.2 1.05]);
set(axa,'FontSize',fs_a,'TickLabelInterpreter','latex','LineWidth',2);
box(axa,'on');
axis(axa,'square');
colormap(axa,turbo(N*10));
clim(axa,[1 60]);

% Colorbar position
cbar_a = colorbar(axa);
cbar_a.Position = [0.311 0.17 0.012 0.72];
cbar_a.FontSize = fs_a-2;
cbar_a.LineWidth = 1;
cbar_a.TickLabelInterpreter = 'latex';
cbar_a.Ticks = [20 40 60];

% Inset position
axain = axes('Position',[0.09 0.44 0.28 0.43]);
hold(axain,'on');

for i = 1:N
    a = readmatrix(fullfile(path3a_inset,sprintf('corr_%d.dat',i)));
    plot(axain,a(:,1),a(:,3),'-','Color',plot_colors(i*10,:),'LineWidth',4);
end

% plot(axain,[0 50],[0 0],'--k','LineWidth',1);
xlabel(axain,'$r$','FontSize',fs_l-4,'Interpreter','latex');
ylabel(axain,'$C(r,t)$','FontSize',fs_l-4,'Interpreter','latex');
xlim(axain,[-0.2 50]);
ylim(axain,[-0.2 1.1]);
set(axain,'FontSize',fs_a-4,'TickLabelInterpreter','latex','LineWidth',1.3);
box(axain,'on');
axis(axain,'square');
annotation(gcf,'textbox',[0.32 0.73 0.025 0.15],'String','$\mathrm{Time}$','Interpreter','latex','FontSize',fs_a-4,'Rotation',90,'EdgeColor','none','HorizontalAlignment','center','VerticalAlignment','middle');

% annotation(gcf,'textbox',[0.015 0.87 0.04 0.05],'String','(a)','FontSize',16,'EdgeColor','none');

%% ===================== PANEL (b) =====================

files_b = {'lam_0.dat','lam_1.dat','lam_3.dat','lam_5.dat','lam_7.dat','lam_9.dat'};
colors_b = {[0.95 0.35 0.35],[1.00 0.15 0.15],[0.90 0.00 0.00],[0.75 0.00 0.00],[0.55 0.00 0.00],[0.40 0.00 0.00]};
markers_b = {'o','s','D','>','<','+'};
legend_b = {'$(0.15,0.0,1.0)$','$(0.15,1.0,1.0)$','$(0.15,3.0,1.0)$','$(0.15,5.0,1.0)$','$(0.15,7.0,1.0)$','$(0.05,9.0,0.5)$'};

axb = axes('Position',pos_b);
hold(axb,'on');

hdata_b = gobjects(1,length(files_b));

for i = 1:length(files_b)
    a = readmatrix(fullfile(path3b,files_b{i}));
    hdata_b(i) = plot(axb,a(:,1),a(:,2),'LineStyle','none','Color',colors_b{i},'Marker',markers_b{i},'MarkerSize',5,'MarkerFaceColor','none','MarkerEdgeColor',colors_b{i},'LineWidth',1.7);
end

a1 = readmatrix(fullfile(path3b,'slope_line_t025.dat'));
a2 = readmatrix(fullfile(path3b,'slope_line_t033.dat'));

h025b = plot(axb,a1(:,1),a1(:,2),'--k','LineWidth',1.7);
h033b = plot(axb,a2(:,1),a2(:,2),'-.k','LineWidth',1.7);

axb.XScale = 'log';
axb.YScale = 'log';
axb.XMinorTick = 'on';
axb.YMinorTick = 'on';

xlim(axb,[0.35 1.3e3]);
ylim(axb,[5e-1 2e1]);
xticks(axb,[1 10 100 1000]);
yticks(axb,[1 10]);

xlabel(axb,'$t$','FontSize',fs_l,'Interpreter','latex');
% ylabel(axb,'$L(t)$','FontSize',fs_l,'Interpreter','latex');
set(axb,'FontSize',fs_a,'TickLabelInterpreter','latex','LineWidth',2);
box(axb,'on');
axis(axb,'square');
% Data legend
lg_b = legend(axb,hdata_b,legend_b,'Interpreter','latex','FontSize',fs_a-6,'Box','off','NumColumns',2);
title(lg_b,'$(\rho_0,\lambda,\tau)$','Interpreter','latex','FontSize',fs_a-4);
lg_b.Position = [0.465 0.20 0.18 0.18];

% Second invisible axes for slope legend
axb2 = axes('Position',pos_b,'Visible','off');
lg_bs = legend(axb2,[h025b h033b],{'$L(t)\sim t^{0.25}$','$L(t)\sim t^{0.33}$'},'Interpreter','latex','FontSize',fs_a-4,'Box','off');
lg_bs.Position = [0.395 0.76 0.16 0.10];

% annotation(gcf,'textbox',[0.345 0.87 0.04 0.05],'String','(b)','FontSize',16,'EdgeColor','none');

%% ===================== PANEL (c) =====================

files_c = {'plotted_tau_0.50.dat','plotted_tau_1.00.dat','plotted_tau_1.50.dat','plotted_tau_2.00.dat'};
colors_c = {[0.90 0.00 0.00],[0.75 0.00 0.00],[0.55 0.00 0.00],[0.40 0.00 0.00]};
markers_c = {'o','s','D','>'};
legend_c = {'$(0.15,7.0,0.5)$','$(0.15,7.0,1.0)$','$(0.15,7.0,1.5)$','$(0.15,7.0,2.0)$'};

axc = axes('Position',pos_c);
hold(axc,'on');

hdata_c = gobjects(1,length(files_c));

for i = 1:length(files_c)
    a = readmatrix(fullfile(path3c,files_c{i}));
    hdata_c(i) = plot(axc,a(:,1),a(:,2),'LineStyle','none','Color',colors_c{i},'Marker',markers_c{i},'MarkerSize',5,'MarkerFaceColor','none','MarkerEdgeColor',colors_c{i},'LineWidth',1.7);
end

a1 = readmatrix(fullfile(path3c,'plotted_slope_0.25.dat'));
a2 = readmatrix(fullfile(path3c,'plotted_slope_0.33.dat'));
a1 = a1(2:end,:);

h025c = plot(axc,a1(:,1),a1(:,2),'--k','LineWidth',1.7);
h033c = plot(axc,a2(:,1),a2(:,2),'-.k','LineWidth',1.7);

axc.XScale = 'log';
axc.YScale = 'log';
axc.XMinorTick = 'on';
axc.YMinorTick = 'on';

xlim(axc,[0.05 500]);
ylim(axc,[5e-1 2e1]);
% ylim(axc,[0.8 20]);
xticks(axc,[0.1 1 10 100]);
yticks(axc,[1 10]);

xlabel(axc,'$t$','FontSize',fs_l,'Interpreter','latex');
% ylabel(axc,'$L(t)$','FontSize',fs_l,'Interpreter','latex');
set(axc,'FontSize',fs_a,'TickLabelInterpreter','latex','LineWidth',2);
box(axc,'on');
axis(axc,'square');
% Data legend
lg_c = legend(axc,hdata_c,legend_c,'Interpreter','latex','FontSize',fs_a-6,'Box','off');
title(lg_c,'$(\rho_0,\lambda,\tau)$','Interpreter','latex','FontSize',fs_a-4);
lg_c.Position = [0.86 0.24 0.15 0.16];

% Slope legend
axc2 = axes('Position',pos_c,'Visible','off');
lg_cs = legend(axc2,[h025c h033c],{'$L(t)\sim t^{0.25}$','$L(t)\sim t^{0.33}$'},'Interpreter','latex','FontSize',fs_a-4,'Box','off');
lg_cs.Position = [0.725 0.76 0.16 0.10];


annotation(gcf,'textbox',[0 0.87 0.04 0.05],'String','(a)','FontSize',fs_a,'EdgeColor','none');
annotation(gcf,'textbox',[0.35 0.87 0.04 0.05],'String','(b)','FontSize',fs_a,'EdgeColor','none');
annotation(gcf,'textbox',[0.68 0.87 0.04 0.05],'String','(c)','FontSize',fs_a,'EdgeColor','none');

annotation(gcf,'textbox',[0.37 0.45 0.04 0.05],'String','$L(t)$','FontSize',fs_l,'EdgeColor','none','Interpreter','latex','Rotation',90);
annotation(gcf,'textbox',[0.7 0.45 0.04 0.05],'String','$L(t)$','FontSize',fs_l,'EdgeColor','none','Interpreter','latex','Rotation',90);

%% Bring panel (a) inset to front
uistack(axain,'top');

exportgraphics(gcf, fullfile(pwd, 'Figure3.jpg'),'Resolution',600)