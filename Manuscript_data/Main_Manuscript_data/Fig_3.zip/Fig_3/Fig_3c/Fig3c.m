clear; clc; close all;

data_path = fullfile(pwd,'data');


files = {'plotted_tau_0.50.dat','plotted_tau_1.00.dat','plotted_tau_1.50.dat','plotted_tau_2.00.dat'};
colors = {[0.90 0.00 0.00],[0.75 0.00 0.00],[0.55 0.00 0.00],[0.40 0.00 0.00]};
markers = {'o','s','D','>'};
legend_text = {'$(0.15,7.0,0.5)$','$(0.15,7.0,1.0)$','$(0.15,7.0,1.5)$','$(0.15,7.0,2.0)$'};

figure(1); clf; hold on;
hdata = gobjects(1,length(files));

for i = 1:length(files)
    a = readmatrix(fullfile(data_path,files{i}));
    hdata(i) = plot(a(:,1),a(:,2),'LineStyle','none','Color',colors{i},'Marker',markers{i},'MarkerSize',8,'MarkerFaceColor','none','MarkerEdgeColor',colors{i},'LineWidth',2.7,'DisplayName',legend_text{i});
end

a1 = readmatrix(fullfile(data_path,'plotted_slope_0.25.dat'));
a2 = readmatrix(fullfile(data_path,'plotted_slope_0.33.dat'));
a1 = a1(2:end,:);

h025 = plot(a1(:,1),a1(:,2),'--k','LineWidth',2.5,'DisplayName','$L(t)\sim t^{0.25}$');
h033 = plot(a2(:,1),a2(:,2),'-.k','LineWidth',2.5,'DisplayName','$L(t)\sim t^{0.33}$');

ax = gca;
ax.XScale = 'log';
ax.YScale = 'log';
ax.FontSize = 25;
ax.LineWidth = 3;
ax.XMinorTick = 'off';
ax.YMinorTick = 'off';
ax.TickLabelInterpreter = 'latex';

xlim([0.05 500]);
ylim([0.8 20]);
xticks([0.1 1 10 100]);
yticks([1 10]);

xlabel('$t$','Interpreter','latex','FontSize',36);
ylabel('$L(t)$','Interpreter','latex','FontSize',36);

set(gcf,'Units','centimeters','Position',[2 2 18 18],'Color','w');
box on;
axis square;

lg_data = legend(hdata,'Interpreter','latex','FontSize',24,'Box','off');
title(lg_data,'$(\rho_0,\lambda,\tau)$','Interpreter','latex');
lg_data.Position = [0.51 0.23 0.43 0.18];

ax2 = axes('Position',ax.Position,'Visible','off');
lg_slope = legend(ax2,[h025 h033],{'$L(t)\sim t^{0.25}$','$L(t)\sim t^{0.33}$'},'Interpreter','latex','FontSize',24,'Box','off');
lg_slope.Position = [0.20 0.76 0.28 0.10];

lg_data.LineWidth = 1.5;
lg_slope.LineWidth = 1.5;
ax.XMinorTick = 'on';
ax.YMinorTick = 'on';