clear; clc; close all;

data_path = fullfile(pwd,'Data');

files = {'lam_0.dat','lam_1.dat','lam_3.dat','lam_5.dat','lam_7.dat','lam_9.dat'};
colors = {[0.95 0.35 0.35],[1.00 0.15 0.15],[0.90 0.00 0.00],[0.75 0.00 0.00],[0.55 0.00 0.00],[0.40 0.00 0.00]};
markers = {'o','s','D','>','<','+'};
legend_text = {'$(0.15,0.0,1.0)$','$(0.15,1.0,1.0)$','$(0.15,3.0,1.0)$','$(0.15,5.0,1.0)$','$(0.15,7.0,1.0)$','$(0.05,9.0,0.5)$'};

figure(1); clf; hold on;

hdata = gobjects(1,length(files));

for i = 1:length(files)
    a = readmatrix(fullfile(data_path,files{i}));
    hdata(i) = plot(a(:,1),a(:,2),'LineStyle','none','Color',colors{i},'Marker',markers{i},'MarkerSize',8,'MarkerFaceColor','none','MarkerEdgeColor',colors{i},'LineWidth',2.7,'DisplayName',legend_text{i});
end

a1 = readmatrix(fullfile(data_path,'slope_line_t025.dat'));
a2 = readmatrix(fullfile(data_path,'slope_line_t033.dat'));

h025 = plot(a1(:,1),a1(:,2),'--k','LineWidth',2.5,'DisplayName','$L(t)\sim t^{0.25}$');
h033 = plot(a2(:,1),a2(:,2),'-.k','LineWidth',2.5,'DisplayName','$L(t)\sim t^{0.33}$');

ax = gca;
ax.XScale = 'log';
ax.YScale = 'log';
ax.FontSize = 25;
ax.LineWidth = 3;
ax.XMinorTick = 'off';
ax.YMinorTick = 'off';
ax.TickLabelInterpreter = 'latex';

xlim([0.35 1.3e3]);
ylim([0.25 18]);
xticks([1 10 100 1000]);
yticks([1 10]);

xlabel('$t$','Interpreter','latex','FontSize',32);
ylabel('$L(t)$','Interpreter','latex','FontSize',32);

box on;
axis square;

set(gcf,'Units','centimeters','Position',[2 2 18 18],'Color','w');

lg_data = legend(hdata,'Interpreter','latex','FontSize',22,'Box','off','NumColumns',2);
title(lg_data,'$(\rho_0,\lambda,\tau)$','Interpreter','latex');
lg_data.Position = [0.4 0.17 0.35 0.25];

ax2 = axes('Position',ax.Position,'Visible','off');
lg_slope = legend(ax2,[h025 h033],{'$L(t)\sim t^{0.25}$','$L(t)\sim t^{0.33}$'},'Interpreter','latex','FontSize',24,'Box','off');
lg_slope.Position = [0.18 0.8 0.3 0.03];

lg_data.LineWidth = 1.5;
lg_slope.LineWidth = 1.5;
ax.XMinorTick = 'on';
ax.YMinorTick = 'on';