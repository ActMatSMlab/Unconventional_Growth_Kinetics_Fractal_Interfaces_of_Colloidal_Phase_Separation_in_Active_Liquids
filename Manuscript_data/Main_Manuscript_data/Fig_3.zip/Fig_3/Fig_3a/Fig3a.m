clear; close all;

path_main  = fullfile(pwd,'scaling_r_by_l');
path_inset = fullfile(pwd,'unscaled_data');

N = 20;

% Colors
plot_colors = turbo(N*10);
colormap(turbo(N*10));

%% ================= MAIN FIGURE =================
figure(1); clf
set(gcf,'Units','centimeters','Position',[2 2 20 15]);

ax1 = axes('Position',[0.15 0.20 0.68 0.70]);
hold(ax1,'on');

for i = 1:N
    a = readmatrix(fullfile(path_main,sprintf('corr_%d.dat',i)));
    plot(ax1,a(:,1),a(:,3),'-','Color',plot_colors(i*10,:),'LineWidth',6);
end

xlabel(ax1,'$x$','FontSize',33,'Interpreter','latex');
ylabel(ax1,'$f(x)$','FontSize',33,'Interpreter','latex');

xlim(ax1,[-0.2 20]);
ylim(ax1,[-0.2 1.05]);

ax1.FontSize = 25;
ax1.LineWidth = 3;
ax1.TickLabelInterpreter = 'latex';
box(ax1,'on');
axis(ax1,'square');

%% ================= COLORBAR =================
clim(ax1,[1 60]);

cbar = colorbar(ax1);
cbar.Position = [0.76 0.20 0.025 0.703];
cbar.FontSize = 18;
cbar.LineWidth = 0.1;
cbar.TickLabelInterpreter = 'latex';

%% ================= INSET =================
ax2 = axes('Position',[0.39 0.48 0.40 0.40]);
hold(ax2,'on');

for i = 1:N
    a = readmatrix(fullfile(path_inset,sprintf('corr_%d.dat',i)));
    plot(ax2,a(:,1),a(:,3),'-','Color',plot_colors(i*10,:),'LineWidth',2.5);
end

plot(ax2,[0 50],[0 0],'--k','LineWidth',2);

xlabel(ax2,'$r$','FontSize',25,'Interpreter','latex');
ylabel(ax2,'$C(r,t)$','FontSize',25,'Interpreter','latex');

xlim(ax2,[-0.1 50]);
ylim(ax2,[-0.2 1.1]);

ax2.FontSize = 20;
ax2.LineWidth = 2;
ax2.TickLabelInterpreter = 'latex';
box(ax2,'on');
axis(ax2,'square');

% Keep inset above main axes
uistack(ax2,'top');

%% ================= TIME LABEL =================
annotation(gcf,'textbox',[0.79 0.77 0.04 0.18], 'String','$\mathrm{Time}$', 'Interpreter','latex', ...
    'FontSize',20, 'Rotation',90, 'EdgeColor','none', 'HorizontalAlignment','center', 'VerticalAlignment','middle');