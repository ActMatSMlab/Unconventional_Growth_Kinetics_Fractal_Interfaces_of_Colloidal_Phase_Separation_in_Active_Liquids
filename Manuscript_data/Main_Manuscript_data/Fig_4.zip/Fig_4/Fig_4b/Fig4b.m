clear; close all;

path  = pwd;%fullfile(pwd,'cusp_data');
% path_inset = fullfile(pwd,'unscaled_data');
a0 = readmatrix(fullfile(path, 'fitting_lines_cusp/line_exp_0.5.dat'));
a1 = readmatrix(fullfile(path, 'fitting_lines_cusp/line_exp_0.66.dat'));
a2 = readmatrix(fullfile(path, 'fitting_lines_cusp/line_exp_1.0.dat'));

N = 10;

% Colors
plot_colors = turbo(N*10);
colormap(turbo(N*10));

%% ================= MAIN FIGURE =================
figure(1); clf
set(gcf,'Units','centimeters','Position',[2 2 20 15]);

ax1 = axes('Position',[0.15 0.20 0.68 0.70]);
hold(ax1,'on');

for i = 1:N
    a = readmatrix(fullfile(path,sprintf('cusp_data/corr_%d.dat',i)));
    plot(ax1,a(:,1),a(:,3),'-','Color',plot_colors(i*10,:),'LineWidth',6);
end
h1 = plot(a0(:,1), a0(:,3), '--k','linewidth',3);
h2 = plot(a1(:,1), a1(:,3), '-.k','linewidth',3);
h3 = plot(a2(:,1), a2(:,3), ':k','linewidth',3);

xlabel(ax1,'$x$','FontSize',33,'Interpreter','latex');
ylabel(ax1,'$1-f(x)$','FontSize',33,'Interpreter','latex');
set(ax1, 'XScale', 'log')
set(ax1, 'YScale', 'log')
xlim(ax1,[0.28 20]);
ylim(ax1,[0.22 1.05]);
xticks(ax1,[1,10])
yticks(ax1,[0.4;0.6;0.9])

legend([h1 h2 h3],'$\alpha=0.5$','$\alpha=0.66\pm0.009$','$\alpha=1.0$','Location','southeast','interpreter','latex','Box','off');

ax1.FontSize = 25;
ax1.LineWidth = 3;
ax1.TickLabelInterpreter = 'latex';
box(ax1,'on');
axis(ax1,'square');

%% ================= COLORBAR =================
clim(ax1,[1 60]);

cbar = colorbar(ax1);
cbar.Position = [0.76 0.20 0.025 0.703];
cbar.FontSize = 20;
cbar.LineWidth = 0.1;
cbar.TickLabelInterpreter = 'latex';




%% ================= TIME LABEL =================
annotation(gcf,'textbox',[0.79 0.77 0.04 0.18], 'String','$\mathrm{Time}$', 'Interpreter','latex', ...
    'FontSize',20, 'Rotation',90, 'EdgeColor','none', 'HorizontalAlignment','center', 'VerticalAlignment','middle');