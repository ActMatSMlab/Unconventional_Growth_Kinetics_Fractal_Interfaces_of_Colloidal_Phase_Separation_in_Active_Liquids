path = pwd;
a0 = readmatrix(fullfile(path, 'frac_plot_data.dat'));
a1 = readmatrix(fullfile(path, 'fitting_line.dat'));


figure(1); clf
hold on; 

loglog(a0(:,1), a0(:,2), 'ro','MarkerSize',8,'linewidth',2);
loglog(a1(:,1), a1(:,2), '-k','linewidth',2);

set(gca, 'XScale', 'log')
set(gca, 'YScale', 'log')
set(gcf,'units','centimeters','position',[0 0 20 15])
set(gca,'FontSize',22);
xlabel('$1/l_b$','FontSize',28,'interpreter','latex')
ylabel('$N(l_b)$','FontSize',28,'interpreter','latex')
axis square;
box on
ylim([10^3 10^5]);
xlim([0.1 1.1]);
xticks([0.1,1])
yticks([10^3 10^4 10^5])
ax = gca;
ax.LineWidth = 3; 
hold off;

legend('','$d_f=1.57\pm0.016$','Location','southeast','interpreter','latex','Box','off');