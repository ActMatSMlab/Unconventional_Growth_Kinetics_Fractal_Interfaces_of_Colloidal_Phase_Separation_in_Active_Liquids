%% ============================================================
% FIGURE 4: Combined 2 x 2 tiled figure
% ============================================================

clear; clc; close all;

base_path = pwd;

path4b_data = fullfile(base_path,'Fig_4b/cusp_data');
path4b_fit = fullfile(base_path,'Fig_4b/fitting_lines_cusp');
path4c_data = fullfile(base_path,'Fig_4c/str_tail_plot/');
path4c_fit = fullfile(base_path,'Fig_4c/fitting_lines_str_tail');

N = 10;
plot_colors = turbo(N*10);

figure(1); clf;
set(gcf,'Units','centimeters','Position',[2 2 26 21],'Color','w');

tl = tiledlayout(2,2,'TileSpacing','compact','Padding','compact');

la = -0.3;
lb = 1.03;
fs_l = 24;
fs_a = 18;

%% ============================================================
% PANEL (a)
% ============================================================

axa = nexttile(tl,1);

img = imread(fullfile(base_path,'Fig4a.jpg'));
imshow(img,'Parent',axa);

axis(axa,'image');
axis(axa,'off');


%% Panel (a) colorbar


colormap(axa,turbo(256));
clim(axa,[-1 1]);

cbar_a = colorbar(axa);
cbar_a.FontSize = fs_a-2;
cbar_a.LineWidth = 1;
cbar_a.TickLabelInterpreter = 'latex';
cbar_a.Ticks = [-1  0  1];

text(axa,la,lb,'(a)','Units','normalized','FontSize',fs_a,'FontWeight','normal','HorizontalAlignment','left','VerticalAlignment','top','Clipping','off');

%% ============================================================
% PANEL (b)
% ============================================================

axb = nexttile(tl,2);
hold(axb,'on');

a0 = readmatrix(fullfile(path4b_fit,'line_exp_0.5.dat'));
a1 = readmatrix(fullfile(path4b_fit,'line_exp_0.66.dat'));
a2 = readmatrix(fullfile(path4b_fit,'line_exp_1.0.dat'));

for i = 1:N
    a = readmatrix(fullfile(path4b_data,sprintf('corr_%d.dat',i)));
    plot(axb,a(:,1),a(:,3),'-','Color',plot_colors(i*10,:),'LineWidth',3);
end

h1b = plot(axb,a0(:,1),a0(:,3),'--k','LineWidth',2);
h2b = plot(axb,a1(:,1),a1(:,3),'-.k','LineWidth',2);
h3b = plot(axb,a2(:,1),a2(:,3),':k','LineWidth',2);

axb.XScale = 'log';
axb.YScale = 'log';

xlim(axb,[0.28 20]);
ylim(axb,[0.22 1.05]);

xticks(axb,[1 10]);
yticks(axb,[0.4 0.6 0.9]);

xlabel(axb,'$x$','FontSize',fs_l,'Interpreter','latex');
ylabel(axb,'$1-f(x)$','FontSize',fs_l,'Interpreter','latex');

set(axb,'FontSize',fs_a,'TickLabelInterpreter','latex','LineWidth',2);

axb.XMinorTick = 'on';
axb.YMinorTick = 'on';

box(axb,'on');
axis(axb,'square');

legend(axb,[h1b h2b h3b],'$\alpha=0.5$','$\alpha=0.66\pm0.009$','$\alpha=1.0$','Location','southeast','Interpreter','latex','FontSize',fs_a-2,'Box','off');

colormap(axb,turbo(N*10));
clim(axb,[1 60]);

cbar_b = colorbar(axb);
cbar_b.FontSize = fs_a-2;
cbar_b.LineWidth = 1;
cbar_b.TickLabelInterpreter = 'latex';
cbar_b.Ticks = [20  40  60];

text(axb,la,lb,'(b)','Units','normalized','FontSize',fs_a,'FontWeight','normal','HorizontalAlignment','left','VerticalAlignment','top','Clipping','off');

%% ============================================================
% PANEL (c)
% ============================================================

axc = nexttile(tl,3);
hold(axc,'on');

a0 = readmatrix(fullfile(path4c_fit,'line_exp_2.5.dat'));
a1 = readmatrix(fullfile(path4c_fit,'line_exp_2.66.dat'));
a2 = readmatrix(fullfile(path4c_fit,'line_exp_3.0.dat'));

for i = 1:N
    a = readmatrix(fullfile(path4c_data,sprintf('str_%d.dat',i)));
    plot(axc,a(:,1),a(:,3),'-','Color',plot_colors(i*10,:),'LineWidth',3);
end

h1c = plot(axc,a0(:,1),a0(:,3),'--k','LineWidth',2);
h2c = plot(axc,a1(:,1),a1(:,3),'-.k','LineWidth',2);
h3c = plot(axc,a2(:,1),a2(:,3),':k','LineWidth',2);

axc.XScale = 'log';
axc.YScale = 'log';

xlim(axc,[0.015 18]);
ylim(axc,[0.002 20]);

xticks(axc,[0.1 1 10]);
yticks(axc,[0.01 0.1 1 10]);

xlabel(axc,'$kL(t)$','FontSize',fs_l,'Interpreter','latex');
ylabel(axc,'$S(k,t)/L(t)^2$','FontSize',fs_l,'Interpreter','latex');

set(axc,'FontSize',fs_a,'TickLabelInterpreter','latex','LineWidth',2);

axc.XMinorTick = 'on';
axc.YMinorTick = 'on';

box(axc,'on');
axis(axc,'square');

legend(axc,[h1c h2c h3c],'$d+\alpha=2.5$','$d+\alpha=2.66\pm0.008$','$d+\alpha=3.0$','Location','southwest','Interpreter','latex','FontSize',fs_a-2,'Box','off');

colormap(axc,turbo(N*10));
clim(axc,[1 60]);

cbar_c = colorbar(axc);
cbar_c.FontSize = fs_a-2;
cbar_c.LineWidth = 1;
cbar_c.TickLabelInterpreter = 'latex';
cbar_c.Ticks = [20 40 60];

text(axc,la,lb,'(c)','Units','normalized','FontSize',fs_a,'FontWeight','normal','HorizontalAlignment','left','VerticalAlignment','top','Clipping','off');

%% ============================================================
% PANEL (d)
% ============================================================

axd = nexttile(tl,4);
hold(axd,'on');

a0 = readmatrix(fullfile(base_path,'Fig_4d/frac_plot_data.dat'));
a1 = readmatrix(fullfile(base_path,'Fig_4d/fitting_line.dat'));

hdata_d = plot(axd,a0(:,1),a0(:,2),'ro','MarkerSize',5,'LineWidth',1.5);
hfit_d = plot(axd,a1(:,1),a1(:,2),'-k','LineWidth',2);

axd.XScale = 'log';
axd.YScale = 'log';

xlim(axd,[0.1 1.1]);
ylim(axd,[1e3 1e5]);

xticks(axd,[0.1 1]);
yticks(axd,[1e3 1e4 1e5]);

xlabel(axd,'$1/l_b$','FontSize',fs_l,'Interpreter','latex');
ylabel(axd,'$N(l_b)$','FontSize',fs_l,'Interpreter','latex');

set(axd,'FontSize',fs_a,'TickLabelInterpreter','latex','LineWidth',2);

axd.XMinorTick = 'on';
axd.YMinorTick = 'on';

box(axd,'on');
axis(axd,'square');

legend(axd,hfit_d,'$d_f=1.57\pm0.016$','Location','southeast','Interpreter','latex','FontSize',fs_a-2,'Box','off');

text(axd,la,lb,'(d)','Units','normalized','FontSize',fs_a,'FontWeight','normal','HorizontalAlignment','left','VerticalAlignment','top','Clipping','off');

%% ============================================================
% FINAL COLORBAR POSITIONS AND TIME LABELS
% ============================================================

drawnow;
pa = axa.Position;
pb = axb.Position;
pc = axc.Position;

cbar_a.Position = [pa(1)+pa(3)+0.022 pa(2)+0.001 0.013 pa(4)-0.002];
cbar_b.Position = [pb(1)+pb(3)-0.002 pb(2) 0.013 pb(4)];
cbar_c.Position = [pc(1)+pc(3)+0.023 pc(2) 0.013 pc(4)];

pabar = cbar_a.Position;
pbbar = cbar_b.Position;
pcbar = cbar_c.Position;

annotation(gcf,'textbox',[pbbar(1)+0.028 pbbar(2)+0.78*pbbar(4) 0.025 0.30*pbbar(4)],'String','$\mathrm{Time}$','Interpreter','latex','FontSize',fs_a-2,'Rotation',90,'EdgeColor','none','HorizontalAlignment','center','VerticalAlignment','middle');

annotation(gcf,'textbox',[pcbar(1)+0.028 pcbar(2)+0.78*pcbar(4) 0.025 0.30*pcbar(4)],'String','$\mathrm{Time}$','Interpreter','latex','FontSize',fs_a-2,'Rotation',90,'EdgeColor','none','HorizontalAlignment','center','VerticalAlignment','middle');


exportgraphics(gcf, fullfile(pwd, 'Figure4.jpg'),'Resolution',600)