clear;
clc;
close all;

L = 256;

%% Read data
data1 = readmatrix("data_FIG_4a.dat", "NumHeaderLines", 1);

%% Reshape phi
% Python:
% phi1 = data1[:,2].reshape((L,L),order="F")

phi1 = reshape(data1(:,3), [L, L]);

%% Figure
fig = figure('Units','inches','Position',[1 1 5 5]);

ax = axes(fig);

%% Plot
imagesc(ax, phi1');
axis(ax, 'image');

% Put origin at lower-left
set(ax, 'YDir', 'normal');

%% Colormap
colormap(ax, jet);

%% Set color range
clim(ax, [-1 1]);

% %% Colorbar
% cb = colorbar(ax);
% 
% % Set colorbar ticks
% cb.Ticks = [-1 -0.5 0 0.5 1.0];
% 
% % Increase colorbar tick-label font size
% cb.FontSize = 12;

%% Remove X/Y ticks
set(ax, 'XTick', []);
set(ax, 'YTick', []);

%% Keep some space for the colorbar
ax.Position = [0.01 0.01 0.99 0.99];

%% Save
exportgraphics(fig, 'Fig4a.jpg', 'Resolution', 300);

drawnow;
