clear; clc; close all;

data_path = pwd;

folders = {'subplot_a','subplot_b','subplot_c','subplot_d','subplot_e','subplot_f','subplot_g','subplot_h','subplot_i'};

legend_text = {'$\rho_0=0.05,\,\lambda=6.0$','$\rho_0=0.10,\,\lambda=6.0$','$\rho_0=0.10,\,\lambda=6.5$','$\lambda=6.0,\,\tau=1.0$','$\lambda=6.5,\,\tau=1.0$','$\lambda=9.0,\,\tau=0.50$','$\rho_0=0.15,\,\tau=0.10$','$\rho_0=0.05,\,\tau=0.50$','$\rho_0=0.15,\,\tau=1.0$'};

panel_label = {'(a)','(b)','(c)','(d)','(e)','(f)','(g)','(h)','(i)'};

figure(1); clf;
set(gcf,'Units','centimeters','Position',[2 2 30 27],'Color','w');

% tl = tiledlayout(3,3,'TileSpacing','compact','Padding','compact');
tl = tiledlayout(3,3,'TileSpacing','compact','Padding','compact');
tl.Units = 'normalized';
tl.OuterPosition = [0.08 0.02 0.91 0.97];

% Y-axis limits and ticks for each subplot
y_limits = {
    [2.8 6.1],   % (a)
    [2.8 6.1],   % (b)
    [2.8 6.1],   % (c)
    [2.8 6.1],   % (d)
    [2.8 6.1],   % (e)
    [3.5 8.1],   % (f)
    [2.8 8.1],   % (g)
    [2.8 6.1],   % (h)
    [2.8 7.1]    % (i)
};

y_ticks = {
    [3 5],       % (a)
    [3 5],       % (b)
    [3 5],       % (c)
    [3 5],       % (d)
    [3 5],       % (e)
    [4 6 8],     % (f)
    [3 5 7],     % (g)
    [3 5],     % (h)
    [3 5 7]      % (i)
};

for i = 1:9

    a1 = readmatrix(fullfile(data_path,folders{i},'scatter_plot.dat'));
    a2 = readmatrix(fullfile(data_path,folders{i},'slope_025.dat'));
    a3 = readmatrix(fullfile(data_path,folders{i},'slope_033.dat'));

    ax = nexttile(tl,i);
    hold(ax,'on');

    h1 = plot(ax,a1(:,1),a1(:,2),'bo','MarkerSize',4,'MarkerFaceColor','none','LineWidth',1.2);
    h2 = plot(ax,a2(:,1),a2(:,2),'--','Color',[1 0.5 0],'LineWidth',2);
    h3 = plot(ax,a3(:,1),a3(:,2),'--','Color',[1 0 1],'LineWidth',2);

    ax.XScale = 'log';
    ax.YScale = 'log';

    xlabel(ax,'$t$','FontSize',18,'Interpreter','latex');
    ylabel(ax,'$L(t)$','FontSize',18,'Interpreter','latex');

    if ismember(i,[7 8])
     xlim(ax,[0.9 15]);       % (g) and (h)
    else
     xlim(ax,[0.9 20.2]);     % all other panels
    end

    xticks(ax,[1 5 10 15 20]);
    ylim(ax,y_limits{i});
    yticks(ax,y_ticks{i});

    set(ax,'FontSize',13,'TickLabelInterpreter','latex','LineWidth',1.5);

    ax.XMinorTick = 'on';
    ax.YMinorTick = 'on';

    box(ax,'on');
    grid(ax,'off');

    lg = legend(ax,[h1 h2 h3],legend_text{i},'$L(t)\sim t^{0.25}$','$L(t)\sim t^{0.33}$','Location','northwest','Interpreter','latex','FontSize',10,'Box','off');

    % text(ax,0.12,0.55,panel_label{i},'Units','normalized','FontSize',14,'FontWeight','normal','HorizontalAlignment','left','VerticalAlignment','top');
    % Panel label
text(ax,-0.15,1.02,panel_label{i}, ...
    'Units','normalized', ...
    'FontSize',14, ...
    'FontWeight','normal', ...
    'HorizontalAlignment','left', ...
    'VerticalAlignment','top');
    
end

annotation(gcf,'textbox',[0.16 0.72 0.2 0.20],'String','For fixed $\tau=1.0$','Interpreter','latex','FontSize',18,'FontWeight','bold','Rotation',90,'EdgeColor','none','HorizontalAlignment','center','VerticalAlignment','middle');

annotation(gcf,'textbox',[0.16 0.40 0.2 0.20],'String','For fixed $\rho_0=0.15$','Interpreter','latex','FontSize',18,'FontWeight','bold','Rotation',90,'EdgeColor','none','HorizontalAlignment','center','VerticalAlignment','middle');

annotation(gcf,'textbox',[0.16 0.10 0.2 0.20],'String','For fixed $\lambda=7.0$','Interpreter','latex','FontSize',18,'FontWeight','bold','Rotation',90,'EdgeColor','none','HorizontalAlignment','center','VerticalAlignment','middle');
