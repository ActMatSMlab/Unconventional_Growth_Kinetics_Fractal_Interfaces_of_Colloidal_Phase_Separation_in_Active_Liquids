path = pwd;

figure(1); clf, hold on
set(gcf,'Units','centimeters','Position',[2 2 20 15]);

a0 = readmatrix(fullfile(path,'main_plot.dat'));
a1 = readmatrix(fullfile(path,'slope_0.24.dat'));
a2 = readmatrix(fullfile(path,'slope_0.33.dat'));

plot(a0(:,1),  a0(:,2), 'bo','markersize',8,'linewidth',3,'DisplayName', '$\rho_g = 0.28, c_b = 5b_0$')
plot(a1(:,1),  a1(:,2), 'r-','markersize',8,'linewidth',3)
plot(a2(:,1),  a2(:,2), 'k-','markersize',8,'linewidth',3)



set(gca, 'XScale', 'log')
set(gca, 'YScale', 'log')
legend('$\rho_e^0 = 0.28, c_e = 5b_0$','$1/z = 1/4$','$1/z =1/3 $','location', 'southeast','interpreter','latex','Box','off')
xlim([150 20000]);
ylim([2 20]);
xticks([1000 10000])
yticks([5 15])
set(gcf,'units','centimeters','position',[0 0 18 15])
set(gca,'FontSize',25);
xlabel('$t~(sec)$','FontSize',28,'interpreter','latex')
ylabel('$L_e(t)/\sigma$','FontSize',28,'interpreter','latex')
axis square;
box on

grid off
set(gca,'FontSize',25,'TickLabelInterpreter','latex','LineWidth',3)
