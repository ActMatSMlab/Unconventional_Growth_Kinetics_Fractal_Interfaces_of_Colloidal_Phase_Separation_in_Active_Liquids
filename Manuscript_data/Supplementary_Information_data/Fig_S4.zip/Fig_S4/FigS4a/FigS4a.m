path_main = fullfile(pwd, 'Main');
path_inset = fullfile(pwd, 'Inset');


%% ================= MAIN FIGURE =================
figure(1); clf
set(gcf,'Units','centimeters','Position',[2 2 20 15]);
N = 250;
d1 = dir(fullfile(path_main,'scaled_*.dat'));
N1 = length(d1);

plot_colors = turbo(N);
colormap(turbo(N));

ax1 = axes('Position',[0.15 0.20 0.68 0.70]);
hold(ax1,'on');
ii = 0;
for i = N-N1:N-1
    ii = ii+1;
    a0 = readmatrix(fullfile(path_main,sprintf('scaled_%d.dat',ii)));
    plot(ax1,a0(:,1),a0(:,2),'-','Color',plot_colors(i+1,:),'LineWidth',4);
end

xlabel(ax1,'$x$','FontSize',33,'Interpreter','latex');
ylabel(ax1,'$f_e(x)$','FontSize',33,'Interpreter','latex');

xlim(ax1,[-0.1 4.5]);
ylim(ax1,[-0.01 0.1]);
xticks(ax1,[0 1 2 3 4]);
yticks(ax1,[0 0.04 0.08]);

ax1.FontSize = 25;
ax1.LineWidth = 3;
box(ax1,'on');
axis(ax1,'square');

axes(ax1);

clim(ax1,[0.5 0.5*25000/60]);
set(ax1,'FontSize',25,'TickLabelInterpreter','latex','LineWidth',3)

% Colorbar
cbar = colorbar(ax1);
cbar.Position = [0.76 0.20 0.025 0.70];
cbar.FontSize = 18;
cbar.LineWidth = 0.1;
cbar.TickLabelInterpreter = "latex";

%% ================= INSET =================
ax2 = axes('Position',[0.39 0.48 0.4 0.4]);
hold(ax2,'on');
d2 = dir(fullfile(path_inset,'inset_*.dat'));
N2 = length(d2);
% plot_colors = turbo(N2);
ii = 0;
for i = N-N2:N-1
    ii = ii+1;
    a0 = readmatrix(fullfile(path_inset,sprintf('inset_%d.dat',ii)));
    plot(ax2,a0(:,1),a0(:,2),'-','Color',plot_colors(i+1,:),'LineWidth',2.5);
end

plot(ax2,[0 33],[0 0],'--k','LineWidth',1.5);

xlabel(ax2,'$r/\sigma$','FontSize',25,'Interpreter','latex');
ylabel(ax2,'$C_e(r,t)$','FontSize',25,'Interpreter','latex');

xlim(ax2,[-0.5 20]);
ylim(ax2,[-0.01 0.1]);
xticks(ax2,[0 10 20 30]);
yticks(ax2,[0 0.04 0.08]);


ax2.FontSize = 20;
ax2.LineWidth = 2;
set(ax2,'FontSize',20,'TickLabelInterpreter','latex','LineWidth',2)
box(ax2,'on');
axis(ax2,'square');

%%
uistack(ax2,'top');
t = annotation(gcf,'textbox',[0.79 0.72 0.04 0.18], 'String','$\mathrm{Time~(min)}$', 'Interpreter','latex', 'FontSize',20, 'Rotation',90, 'EdgeColor','none', ...
    'HorizontalAlignment','center','VerticalAlignment','middle');