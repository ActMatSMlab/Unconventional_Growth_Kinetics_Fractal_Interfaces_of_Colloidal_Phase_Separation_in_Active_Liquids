clear;
clc;
close all;

%% ================= SETTINGS =================

base_path = pwd;

folders = {'modelB','modelB_gaussian_noise','modelB_colored_noise'};

files = {'binary_rho_2.dat','binary_rho_150.dat','binary_rho_400.dat','binary_rho_1000.dat'};

row_labels = {'Model B','Model B + Gaussian noise','Model B + Colored noise'};

%% ================= FIGURE =================

figure(1); clf;

set(gcf,'Units','centimeters','Position',[0 0 32 30],'Color','w');

tl = tiledlayout(3,4,'TileSpacing','compact','Padding','compact');

%% Custom blue-red colormap

cmap = [0 0 0.45; 0.65 0 0];

%% ================= PLOT ALL PANELS =================

for row = 1:3

    for col = 1:4

        %% Tile number
        tileID = (row-1)*4 + col;

        ax = nexttile(tl,tileID);

        %% Read data
        fname = fullfile(base_path,'data',folders{row},files{col});

        data = load(fname);

        x = data(:,1);
        y = data(:,2);
        s = data(:,3);

        %% Grid size
        Nx = max(x);
        Ny = max(y);

        %% Construct image
        img = zeros(Ny,Nx);

        for i = 1:length(s)
            img(y(i),x(i)) = s(i);
        end

        %% Plot
        imagesc(ax,img);

        colormap(ax,cmap);

        clim(ax,[-1 1]);

        axis(ax,'image');

        axis(ax,'tight');

        set(ax,'YDir','normal');

        xticks(ax,[]);

        yticks(ax,[]);

        set(ax,'LineWidth',1.5);

        box(ax,'on');

    end

end

%% ================= ROW LABELS =================

annotation(gcf,'textbox',[0.1 0.69 0.2 0.2],'String','Model B','FontSize',18,'FontWeight','bold','Rotation',90,'EdgeColor','none','HorizontalAlignment','center','VerticalAlignment','middle');

annotation(gcf,'textbox',[0.1 0.37 0.2 0.20],'String','Model B + Gaussian noise','FontSize',18,'FontWeight','bold','Rotation',90,'EdgeColor','none','HorizontalAlignment','center','VerticalAlignment','middle');

annotation(gcf,'textbox',[0.1 0.04 0.2 0.20],'String','Model B + Colored noise','FontSize',18,'FontWeight','bold','Rotation',90,'EdgeColor','none','HorizontalAlignment','center','VerticalAlignment','middle');

%% ================= TIME EVOLUTION ARROW =================

%                    x1   x2     y1    y2
annotation(gcf,'arrow',[0.32 0.85],[0.98 0.98],'LineWidth',1.5);

%                         x     y    width height
annotation(gcf,'textbox',[0.14 0.968 0.20 0.035],'String','Time Evolution','FontSize',18,'FontWeight','bold','EdgeColor','none','HorizontalAlignment','center');
%% ================= OPTIONAL EXPORT =================

exportgraphics(gcf,fullfile(base_path,'Time_Evolution_Comparison.jpg'),'Resolution',600);