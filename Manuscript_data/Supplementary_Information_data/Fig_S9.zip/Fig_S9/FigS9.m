clear; clc; close all;

path = pwd;

N = 20;
plotColors = turbo(200);

figure(1); clf;
set(gcf,'Units','centimeters','Position',[2 2 28 11],'Color','w');

tl = tiledlayout(1,2,'TileSpacing','compact','Padding','loose');

%% ================= PANEL (a): t^-0.25 =================

axa = nexttile(tl,1);
hold(axa,'on');

for i = 1:N
    a = readmatrix(fullfile(path,sprintf('scaling_t_power_0.25/corr_%d.dat',i)));
    plot(axa,a(:,1),a(:,3),'-','Color',plotColors(i*10,:),'LineWidth',3);
end

xlabel(axa,'$rt^{-0.25}$','FontSize',24,'Interpreter','latex');
ylabel(axa,'$C(r,t)$','FontSize',24,'Interpreter','latex');

xlim(axa,[-0.4 20]);
ylim(axa,[-0.2 1.05]);
yticks(axa,[0 0.4 0.8]);

set(axa,'FontSize',17,'TickLabelInterpreter','latex','LineWidth',2);

box(axa,'on');
axis(axa,'square');

colormap(axa,turbo(200));
clim(axa,[1 60]);

cbar_a = colorbar(axa);
cbar_a.FontSize = 13;
cbar_a.LineWidth = 1;
cbar_a.TickLabelInterpreter = 'latex';

text(axa,-0.20,1.04,'(a)','Units','normalized','FontSize',17,'HorizontalAlignment','left','VerticalAlignment','top','Clipping','off');

%% ================= PANEL (b): t^-0.33 =================

axb = nexttile(tl,2);
hold(axb,'on');

for i = 1:N
    a = readmatrix(fullfile(path,sprintf('scaling_t_power_0.33/corr_%d.dat',i)));
    plot(axb,a(:,1),a(:,3),'-','Color',plotColors(i*10,:),'LineWidth',3);
end

xlabel(axb,'$rt^{-0.33}$','FontSize',24,'Interpreter','latex');
ylabel(axb,'$C(r,t)$','FontSize',24,'Interpreter','latex');

xlim(axb,[-0.4 20]);
ylim(axb,[-0.2 1.05]);
yticks(axb,[0 0.4 0.8]);

set(axb,'FontSize',17,'TickLabelInterpreter','latex','LineWidth',2);

box(axb,'on');
axis(axb,'square');

colormap(axb,turbo(200));
clim(axb,[1 60]);

cbar_b = colorbar(axb);
cbar_b.FontSize = 13;
cbar_b.LineWidth = 1;
cbar_b.TickLabelInterpreter = 'latex';

text(axb,-0.20,1.04,'(b)','Units','normalized','FontSize',17,'HorizontalAlignment','left','VerticalAlignment','top','Clipping','off');

%% ================= COLORBAR POSITIONS =================

drawnow;

pa = axa.Position;
pb = axb.Position;

cbar_a.Position = [pa(1)+pa(3)+0.02 pa(2) 0.012 pa(4)];
cbar_b.Position = [pb(1)+pb(3)-0.008 pb(2) 0.012 pb(4)];

%% ================= TIME LABELS =================

pca = cbar_a.Position;
pcb = cbar_b.Position;

annotation(gcf,'textbox',[pca(1)+0.02 pca(2)+0.85*pca(4) 0.025 0.30*pca(4)],'String','$\mathrm{Time}$','Interpreter','latex','FontSize',13,'Rotation',90,'EdgeColor','none','HorizontalAlignment','center','VerticalAlignment','middle');

annotation(gcf,'textbox',[pcb(1)+0.02 pcb(2)+0.85*pcb(4) 0.025 0.30*pcb(4)],'String','$\mathrm{Time}$','Interpreter','latex','FontSize',13,'Rotation',90,'EdgeColor','none','HorizontalAlignment','center','VerticalAlignment','middle');