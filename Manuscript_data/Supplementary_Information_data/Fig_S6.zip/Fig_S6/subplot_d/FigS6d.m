clear; clc; close all;

path = pwd;

figure(1); clf; hold on;

%% ================= WITHOUT NOISE =================

for i = 1:10
    a = readmatrix(fullfile(path,sprintf('without_noise/cusp_%d.dat',i)));
    x = a(:,1);
    y = a(:,2);
    if i == 1
        h1 = plot(x,y,'LineStyle','none','Marker','o','MarkerSize',7,'MarkerFaceColor','w','MarkerEdgeColor','k','LineWidth',1.6,'DisplayName','without noise');
    else
        plot(x,y,'LineStyle','none','Marker','o','MarkerSize',7,'MarkerFaceColor','w','MarkerEdgeColor','k','LineWidth',1.6,'HandleVisibility','off');
    end
end

%% ================= WITH NOISE =================

for i = 1:10
    a = readmatrix(fullfile(path,sprintf('with_noise/cusp_%d.dat',i)));
    x = a(:,1);
    y = a(:,2);
    if i == 1
        h2 = plot(x,y,'LineStyle','none','Marker','s','MarkerSize',7,'MarkerFaceColor','none','MarkerEdgeColor','r','LineWidth',1.6,'DisplayName','with noise');
    else
        plot(x,y,'LineStyle','none','Marker','s','MarkerSize',7,'MarkerFaceColor','none','MarkerEdgeColor','r','LineWidth',1.6,'HandleVisibility','off');
    end
end

%% ================= REFERENCE LINE =================

a1 = readmatrix(fullfile(path,'slope_line_1.dat'));

plot(a1(:,1),a1(:,2),'--','Color','green','LineWidth',2.5,'DisplayName','$L(t)\sim t^{0.25}$');

%% ================= AXES =================

set(gca,'XScale','log','YScale','log');

xlabel('$x$','Interpreter','latex','FontSize',30);
ylabel('$1-f(x)$','Interpreter','latex','FontSize',30);

xlim([0.3 3.5]);
ylim([0.18 1.5]);

xticks([1]);
yticks([1]);

set(gcf,'Units','centimeters','Position',[2 2 18 18]);
set(gca,'FontSize',25,'LineWidth',3,'TickLabelInterpreter','latex');

box on;
axis square;

%% ================= LEGEND =================

lgd = legend([h1 h2],{'without noise','with noise'},'Location','northwest','Interpreter','latex','FontSize',20,'Box','off');

%% ================= PANEL LABEL =================

annotation('textbox',[0.02 0.92 0.05 0.05],'FontSize',28,'String','(d)','FontWeight','normal','LineStyle','none');

hold off;