clear; clc; close all;

data_path = pwd;

files = {'len_without_noise.dat','len_with_noise.dat'};
colors = {'k',[1 0 0]};
markers = {'o','s'};
legend_text = {'without noise','with noise'};

figure(1); clf; hold on;

for i = 1:length(files)
    a = readmatrix(fullfile(data_path,files{i}));
    t = a(:,1);
    y = a(:,2);
    h = plot(t,y,'LineStyle','none','Color',colors{i},'Marker',markers{i},'MarkerSize',7,'MarkerFaceColor','w','MarkerEdgeColor',colors{i},'LineWidth',1.6,'DisplayName',legend_text{i});
end

a1 = readmatrix(fullfile(data_path,'slope_0.25.dat'));
a2 = readmatrix(fullfile(data_path,'slope_0.33.dat'));

rose = [0.85 0.33 0.55];
violet = [0.55 0.25 0.80];

plot(a1(:,1),a1(:,2),'--','Color',violet,'LineWidth',2.5,'DisplayName','$L(t)\sim t^{0.25}$');
plot(a2(:,1),a2(:,2),'--','Color',rose,'LineWidth',2.5,'DisplayName','$L(t)\sim t^{0.33}$');

set(gca,'XScale','log','YScale','log');

xlim([10 6000]);
ylim([5 30]);

xticks([10 100 1000 10000]);
yticks([10]);

xlabel('$t$','Interpreter','latex','FontSize',30);
ylabel('$L(t)$','Interpreter','latex','FontSize',30);

set(gcf,'Units','centimeters','Position',[2 2 18 18],'Color','w');
set(gca,'FontSize',25,'LineWidth',3,'TickLabelInterpreter','latex');

box on;
axis square;

legend('Location','northwest','Interpreter','latex','FontSize',20,'Box','off');

annotation('textbox',[0.02 0.92 0.05 0.05],'FontSize',28,'String','(a)','FontWeight','normal','LineStyle','none');