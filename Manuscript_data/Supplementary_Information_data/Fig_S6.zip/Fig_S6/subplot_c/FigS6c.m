clear; clc; close all;

path = pwd;

times = [700 870 1040 1210 1380 1550 1720 1890 2060 2230];
plotColors = turbo(length(times));

%% ================= MAIN PLOT =================

figure(1); clf;

ax1 = axes;
hold(ax1,'on');

for i = 1:10
    a = readmatrix(fullfile(path,sprintf('without_noise_scaled/cf_scaled_%d.dat',i)));
    x = a(:,1);
    y = a(:,2);
    plot(ax1,x,y,'-','MarkerSize',24,'Color',plotColors(i,:),'LineWidth',7);
end

xlabel(ax1,'$x$','Interpreter','latex','FontSize',30);
ylabel(ax1,'$f(x)$','Interpreter','latex','FontSize',30);

xlim(ax1,[0 10]);
ylim(ax1,[-0.2 1]);

xticks(ax1,[0 2 4 6 8 10]);
yticks(ax1,[-0.2 0 0.2 0.4 0.6 0.8]);

set(gcf,'Units','centimeters','Position',[2 2 20 15]);
set(ax1,'FontSize',25,'LineWidth',3);

box(ax1,'on');
axis(ax1,'square');

%% ================= COLORBAR =================

colormap(ax1,turbo);

cb = colorbar('Position',[0.82 0.16 0.025 0.76]);

clim(ax1,[times(1) times(end)]);
cb.TickLabels = string(times);
cb.Label.String = '';
cb.Ticks = [700 1000 1300 1600 1900 2200];
cb.TickLabels = string(cb.Ticks);

%% ================= INSET =================

ax2 = axes('Position',[0.4564 0.4727 0.34 0.4515]);
hold(ax2,'on');

for i = 1:10
    a = readmatrix(fullfile(path,sprintf('without_noise/new_cf_scaled_%d.dat',i)));
    x = a(:,1);
    y = a(:,2);
    plot(ax2,x,y,'-','MarkerSize',24,'Color',plotColors(i,:),'LineWidth',5);
end

xlabel(ax2,'$r$','Interpreter','latex','FontSize',20);
ylabel(ax2,'$C(r,t)$','Interpreter','latex','FontSize',20);

xlim(ax2,[0 140]);
ylim(ax2,[-0.2 1.05]);

set(ax2,'FontSize',16,'LineWidth',2,'XTick',[0 50 100],'YTick',[0 0.5 1]);

box(ax2,'on');
axis(ax2,'square');

text(ax2,130,0.8,'Time','Rotation',90,'FontSize',16,'HorizontalAlignment','center','VerticalAlignment','middle');

title(ax2,'without noise','FontSize',16,'FontWeight','normal');

%% ================= PANEL LABEL =================

annotation('textbox',[0.02 0.92 0.05 0.05],'String','(c)','FontSize',28,'LineStyle','none');