clear; clc; close all;

%% Base path
base_path = pwd;

%% Folder names: rows
folders = {'l_5','l_7','l_9'};

%% Files: columns
files = {'1.dat','2.dat','3.dat','4.dat'};

%% Column titles
time_labels = {'t = 1','t = 5','t = 10','t = 20'};

%% Row labels
row_labels = {'$\lambda = 5.0$', '$\lambda = 7.0$', '$\lambda = 9.0$'};
%% Figure
figure(1); clf;
set(gcf,'Units','centimeters','Position',[2 2 30 24],'Color','w');

tl = tiledlayout(3,4,'TileSpacing','compact','Padding','compact');

%% Custom blue-red colormap
cmap = [0 0 0.45; 0.75 0 0];

%% Plot all 12 configurations
for row = 1:3

    for col = 1:4

        %% Read data
        data = load(fullfile(base_path,'data',folders{row},files{col}));

        x = data(:,1);
        y = data(:,2);
        s = data(:,3);

        %% Grid dimensions
        Nx = max(x);
        Ny = max(y);

        %% Construct image
        img = zeros(Ny,Nx);

        for k = 1:length(s)
            img(y(k),x(k)) = s(k);
        end

        %% Create tile
        ax = nexttile(tl,(row-1)*4+col);

        imagesc(ax,img);

        colormap(ax,cmap);
        clim(ax,[-1 1]);

        axis(ax,'equal');
        axis(ax,'tight');

        set(ax,'YDir','normal','XTick',[],'YTick',[],'LineWidth',1.5);
        box(ax,'on');

        %% Titles only on top row
        if row == 1
            title(ax,time_labels{col},'FontSize',17,'FontWeight','bold','Interpreter','latex');
        end

    end

end

%% Leave space on left for row labels
tl.Units = 'normalized';
tl.OuterPosition = [0.09 0.02 0.90 0.94];

%% Row labels
annotation(gcf,'textbox',[0.18 0.74 0.07 0.20],'String',row_labels{1},'Interpreter','latex','FontSize',18,'Rotation',90,'EdgeColor','none','HorizontalAlignment','center','VerticalAlignment','middle');

annotation(gcf,'textbox',[0.18 0.45 0.07 0.20],'String',row_labels{2},'Interpreter','latex','FontSize',18,'Rotation',90,'EdgeColor','none','HorizontalAlignment','center','VerticalAlignment','middle');

annotation(gcf,'textbox',[0.18 0.15 0.07 0.20],'String',row_labels{3},'Interpreter','latex','FontSize',18,'Rotation',90,'EdgeColor','none','HorizontalAlignment','center','VerticalAlignment','middle');

%% Save
exportgraphics(gcf,fullfile(base_path,'time_evolution_3x4.png'),'Resolution',600);