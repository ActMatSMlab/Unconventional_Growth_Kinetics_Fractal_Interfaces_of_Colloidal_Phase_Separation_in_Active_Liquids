clear;
clc;
close all;

%% Load data
% data = load('/media/pragya/Drive1/DataForGithubUpload-20260918T062452Z-1-001/DataForGithubUpload/Fig_S12/data/l_5/1.dat');
%% Base path
base_path = fileparts(pwd);

%% Load data
data = load(fullfile(base_path,'data','l_5','1.dat'));

x = data(:,1);
y = data(:,2);
s = data(:,3);   % spin values: -1 or +1

%% Grid size
Nx = max(x);
Ny = max(y);

%% Create image matrix
img = zeros(Ny, Nx);

% Assign values
% +1 -> red
% -1 -> blue
for i = 1:length(s)
    img(y(i), x(i)) = s(i);
end

%% Plot
figure('Color','w');

imagesc(img);

% Custom colormap
% row 1 -> blue  (-1)
% row 2 -> red   (+1)
colormap([0 0 0.45;      % deep blue
          0.65 0 0]);    % deep red

% Set color limits so:
% -1 maps to blue
% +1 maps to red
caxis([-1 1]);

axis equal tight;

% Put origin at bottom-left
set(gca,'YDir','normal');

% Remove ticks if desired
xticks([]);
yticks([]);

% Optional border thickness
set(gca,'LineWidth',2);

% Optional save
% exportgraphics(gcf,'spin_configuration.png','Resolution',300);