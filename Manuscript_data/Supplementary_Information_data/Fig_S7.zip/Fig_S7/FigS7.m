clear; clc; close all;

path = pwd;

a0 = readmatrix(fullfile(path,'subplot_a.dat'));
a1 = readmatrix(fullfile(path,'subplot_b.dat'));

figure(1); clf;
set(gcf,'Units','centimeters','Position',[2 2 30 10],'Color','w');

tl = tiledlayout(1,2,'TileSpacing','compact','Padding','compact');

%% ================= PANEL (a) =================

axa = nexttile(tl,1);
hold(axa,'on');

plot(axa,a0(:,1),a0(:,2),'-ok','MarkerSize',7,'MarkerFaceColor','none','LineWidth',1.5);

xlabel(axa,'$\lambda$','FontSize',28,'Interpreter','latex');
ylabel(axa,'$L_s/L(0.5)$','FontSize',25,'Interpreter','latex');

xlim(axa,[0 7]);
ylim(axa,[2 5]);

xticks(axa,[0 1 3 5 7]);
yticks(axa,[2 3 4 5]);

set(axa,'FontSize',20,'LineWidth',2,'TickLabelInterpreter','latex');

box(axa,'on');
% axis(axa,'square');

text(axa,0.04,0.92,'(a)','Units','normalized','FontSize',20,'FontAngle','italic');

text(axa,0.50,0.24,'$\tau=1.0$','Units','normalized','FontSize',18,'Interpreter','latex','FontWeight','bold');

%% ================= PANEL (b) =================

axb = nexttile(tl,2);
hold(axb,'on');

plot(axb,a1(:,1),a1(:,2),'-ok','MarkerSize',7,'MarkerFaceColor','none','LineWidth',1.5);

xlabel(axb,'$\tau$','FontSize',28,'Interpreter','latex');
ylabel(axb,'$L_s/L(0.5)$','FontSize',25,'Interpreter','latex');

xlim(axb,[0.5 2]);
ylim(axb,[2 5]);

xticks(axb,[0.5 1 1.5 2]);
yticks(axb,[2 3 4 5]);

set(axb,'FontSize',20,'LineWidth',2,'TickLabelInterpreter','latex');

box(axb,'on');
% axis(axb,'square');

text(axb,0.04,0.92,'(b)','Units','normalized','FontSize',20,'FontAngle','italic');

text(axb,0.43,0.24,'$\lambda=7.0$','Units','normalized','FontSize',18,'Interpreter','latex','FontWeight','bold');