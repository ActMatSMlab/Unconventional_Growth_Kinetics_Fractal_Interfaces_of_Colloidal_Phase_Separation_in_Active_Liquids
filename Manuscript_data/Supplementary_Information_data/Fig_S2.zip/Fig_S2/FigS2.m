data = readmatrix('data.csv');

x = data(:,1);
y = data(:,2);
err_neg = data(:,3);
err_pos = data(:,4);

figure(1); clf; hold on;

errorbar(x,y,err_neg,err_pos,'o','Color','b','MarkerEdgeColor','b','MarkerFaceColor','none','MarkerSize',12,'LineWidth',2,'CapSize',8);
plot([0 200],[1.23 1.23],'--k','LineWidth',3);
xlabel('$t~(\mathrm{min})$','FontSize',30,'Interpreter','latex');
ylabel('$D_{eff}~(\mu\mathrm{m}^2/\mathrm{sec})$','FontSize',30,'Interpreter','latex');

xlim([0 210]);
ylim([0 3]);
xticks([0 50 100 150 200]);
yticks([0 0.5 1 1.5 2 2.5 3]);

set(gca,'FontSize',24,'TickLabelInterpreter','latex','LineWidth',3);
set(gcf,'Units','centimeters','Position',[2 2 18 18],'Color','w');

box on;
axis square;