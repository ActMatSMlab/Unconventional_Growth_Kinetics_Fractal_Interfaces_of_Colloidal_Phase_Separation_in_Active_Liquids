clear;
clc;
close all;

%% Base path
base_path = pwd;

%% Data folders
data_paths = {fullfile(base_path,'data','OD1'), fullfile(base_path,'data','OD5'), fullfile(base_path,'data','OD10')};

%% Filenames
files = {{'OD1_binary_1.dat','OD1_binary_2.dat','OD1_binary_3.dat','OD1_binary_4.dat'}, {'OD5_binary_1.dat','OD5_binary_2.dat','OD5_binary_3.dat','OD5_binary_4.dat'}, {'OD10_binary_1.dat','OD10_binary_2.dat','OD10_binary_3.dat','OD10_binary_4.dat'}};

%% Row labels
row_labels = {{'$c_e = 1b_0$','$\rho_e^0 = 0.26$'}, {'$c_e = 5b_0$','$\rho_e^0 = 0.28$'}, {'$c_e = 10b_0$','$\rho_e^0 = 0.23$'}};

%% Column labels
time_labels = {'$t = 1$ min','$t = 30$ min','$t = 100$ min','$t = 200$ min'};

%% Colormap
cmap = [0 0 0.45; 0.65 0 0];

%% Create figure
figure(1);
clf;
set(gcf,'Units','centimeters','Position',[2 2 30 24],'Color','w');

tl = tiledlayout(3,4,'TileSpacing','compact','Padding','compact');

%% Store axes handles
ax_grid = gobjects(3,4);

%% Plot all configurations
for row = 1:3

    for col = 1:4

        filename = fullfile(data_paths{row},files{row}{col});
        data = readmatrix(filename);

        x = data(:,1);
        y = data(:,2);
        s = data(:,3);

        Nx = max(x) + 1;
        Ny = max(y) + 1;

        img = zeros(Ny,Nx);

        for i = 1:length(s)
            img(y(i)+1,x(i)+1) = s(i);
        end

        img = flipud(img);

        ax = nexttile(tl,(row-1)*4+col);
        ax_grid(row,col) = ax;

        imagesc(ax,img);

        colormap(ax,cmap);
        clim(ax,[-1 1]);

        axis(ax,'equal');
        axis(ax,'tight');

        set(ax,'YDir','normal','XTick',[],'YTick',[],'LineWidth',1.5);
        box(ax,'on');

        if row == 1
            title(ax,time_labels{col},'Interpreter','latex','FontSize',17,'FontWeight','normal');
        end

    end

end

%% Row labels
for row = 1:3

    ax = ax_grid(row,1);

    yl = ylabel(ax,row_labels{row},'Interpreter','latex','FontSize',15,'Rotation',90,'HorizontalAlignment','center','VerticalAlignment','middle');

    yl.Units = 'normalized';
    yl.Position = [-0.18 0.5 0];

end

%% Save figure
output_file = fullfile(base_path,'Fig_S14_combined.png');
exportgraphics(gcf,output_file,'Resolution',300);