clear;
clc;
close all;

%% =============================================================
% Base path
%% =============================================================

base_path = '/media/pragya/Drive1/DataForGithubUpload-20260918T062452Z-1-001/DataForGithubUpload/Fig_S14';


%% =============================================================
% Data folders
%% =============================================================

data_paths = {
    fullfile(base_path,'data','OD1')
    fullfile(base_path,'data','OD5')
    fullfile(base_path,'data','OD10')
};


%% =============================================================
% Filenames
%
% 1 = t = 1 min
% 2 = t = 30 min
% 3 = t = 100 min
% 4 = t = 200 min
%% =============================================================

files = {
    { ...
    'OD1_binary_1.dat', ...
    'OD1_binary_2.dat', ...
    'OD1_binary_3.dat', ...
    'OD1_binary_4.dat' ...
    }

    { ...
    'OD5_binary_1.dat', ...
    'OD5_binary_2.dat', ...
    'OD5_binary_3.dat', ...
    'OD5_binary_4.dat' ...
    }

    { ...
    'OD10_binary_1.dat', ...
    'OD10_binary_2.dat', ...
    'OD10_binary_3.dat', ...
    'OD10_binary_4.dat' ...
    }
};


%% =============================================================
% Row labels
%% =============================================================

row_labels = {
    {'$c_e = 1b_0$',  '$\rho_e^0 = 0.26$'}
    {'$c_e = 5b_0$',  '$\rho_e^0 = 0.28$'}
    {'$c_e = 10b_0$', '$\rho_e^0 = 0.23$'}
};


%% =============================================================
% Column labels
%% =============================================================

time_labels = {
    '$t = 1$ min'
    '$t = 30$ min'
    '$t = 100$ min'
    '$t = 200$ min'
};


%% =============================================================
% Create figure
%
% Narrower figure gives much smaller horizontal gaps between
% the square panels.
%% =============================================================

figure('Color','w',...
       'Units','normalized',...
       'Position',[0.18 0.05 0.64 0.90]);


tiledlayout(3,4,...
    'TileSpacing','compact',...
    'Padding','compact');


%% =============================================================
% Colormap
%% =============================================================

cmap = [0 0 0.45;
        0.65 0 0];


%% =============================================================
% Store axes handles
%% =============================================================

ax_grid = gobjects(3,4);


%% =============================================================
% Plot all 12 configurations
%% =============================================================

for row = 1:3

    for col = 1:4

        %% -----------------------------------------------------
        % Load data
        %% -----------------------------------------------------

        filename = fullfile(data_paths{row},files{row}{col});

        data = load(filename);

        x = data(:,1);
        y = data(:,2);
        s = data(:,3);


        %% -----------------------------------------------------
        % Grid size
        %% -----------------------------------------------------

        Nx = max(x) + 1;
        Ny = max(y) + 1;


        %% -----------------------------------------------------
        % Create image matrix
        %% -----------------------------------------------------

        img = zeros(Ny,Nx);


        %% -----------------------------------------------------
        % Assign spin values
        %% -----------------------------------------------------

        for i = 1:length(s)

            img(y(i)+1,x(i)+1) = s(i);

        end


        %% -----------------------------------------------------
        % Flip image upside down
        %% -----------------------------------------------------

        img = flipud(img);


        %% -----------------------------------------------------
        % Create subplot
        %% -----------------------------------------------------

        ax = nexttile;

        ax_grid(row,col) = ax;

        imagesc(ax,img);

        colormap(ax,cmap);

        caxis(ax,[-1 1]);

        axis(ax,'equal');
        axis(ax,'tight');

        set(ax,'YDir','normal');

        xticks(ax,[]);
        yticks(ax,[]);

        set(ax,'LineWidth',1.5);


        %% -----------------------------------------------------
        % Column titles
        %% -----------------------------------------------------

        if row == 1

            title(ax,time_labels{col},...
                'Interpreter','latex',...
                'FontSize',17,...
                'FontWeight','normal');

        end

    end

end


%% =============================================================
% Add row labels
%
% Labels are attached directly to the first-column axes.
% This avoids the previous problem where labels appeared on
% the third column.
%% =============================================================

for row = 1:3

    ax = ax_grid(row,1);

    yl = ylabel(ax,...
        row_labels{row},...
        'Interpreter','latex',...
        'FontSize',15,...
        'Rotation',90,...
        'HorizontalAlignment','center',...
        'VerticalAlignment','middle');

    % Use normalized coordinates for reliable positioning
    yl.Units = 'normalized';

    % Move label to the left of the first column
    yl.Position = [-0.18 0.5 0];

end


%% =============================================================
% Save
%% =============================================================

output_file = fullfile(base_path,'Fig_S14_combined.png');

exportgraphics(gcf,...
    output_file,...
    'Resolution',300);