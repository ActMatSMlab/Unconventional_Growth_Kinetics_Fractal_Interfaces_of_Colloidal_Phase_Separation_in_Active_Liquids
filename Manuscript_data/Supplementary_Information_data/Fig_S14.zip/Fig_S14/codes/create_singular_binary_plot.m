clear;
clc;
close all;

%% Base path
base_path = fileparts(pwd);

%% Load data
data = load(fullfile(base_path,'data','OD10','OD10_binary_4.dat'));

x = data(:,1);
y = data(:,2);
s = data(:,3);   % spin values: -1 or +1

%% Grid size
Nx = max(x) + 1;
Ny = max(y) + 1;

%% Create image matrix
img = zeros(Ny, Nx);

%% Assign values
for i = 1:length(s)
    img(y(i)+1, x(i)+1) = s(i);
end

%% Flip image upside down
img = flipud(img);

%% Plot
figure('Color','w');

imagesc(img);

colormap([0 0 0.45;
          0.65 0 0]);

caxis([-1 1]);

axis equal tight;

set(gca,'YDir','normal');

xticks([]);
yticks([]);

set(gca,'LineWidth',2);

% Optional save
% exportgraphics(gcf,'spin_configuration.png','Resolution',300);