path = pwd;

a0 = readmatrix(fullfile(path, 'PS20_time_length_scale.txt'));
a1 = readmatrix(fullfile(path, 'PS20_one-third.txt'));
a2 = readmatrix(fullfile(path, 'PS20_one-fourth.txt'));

figure(1);
clf
hold on; 



plot(a0(:,1), a0(:,2), 'o','linewidth',1);
plot(a1(:,1), a1(:,2), '-.k','linewidth',2);
plot(a2(:,1), a2(:,2), 'r-','linewidth',2);

set(gca, 'XScale', 'log')
set(gca, 'YScale', 'log')

set(gca, 'XScale', 'log')
set(gca, 'YScale', 'log')
legend('$\rho_e^0 = 0.23, c_e = 5b_0$','$1/z = 1/3$','$1/z =1/4 $','location', 'northwest','interpreter','latex','Box','off')
xlim([1e0 2e4]);
ylim([6 20]);
xticks([1 100 10000])
yticks([8 15])
set(gcf,'units','centimeters','position',[0 0 20 15])
set(gca,'FontSize',25);
xlabel('$t~(sec)$','FontSize',28,'interpreter','latex')
ylabel('$L_e(t)/\sigma$','FontSize',28,'interpreter','latex')

box on

grid off
set(gca,'FontSize',25,'TickLabelInterpreter','latex','LineWidth',3)