%% ============================================================
% FIGURE S5: Combined 2 x 3 panel figure
% ============================================================

clear; clc; close all;

data_path = pwd;

folders = {'S5a','S5b','S5c','S5d','S5e','S5f'};

legend_text = {'$\rho_e^0 = 0.11,\,c_e = 5b_0$','$\rho_e^0 = 0.22,\,c_e = 5b_0$','$\rho_e^0 = 0.30,\,c_e = 5b_0$','$\rho_e^0 = 0.22,\,c_e = 1b_0$','$\rho_e^0 = 0.23,\,c_e = 5b_0$','$\rho_e^0 = 0.23,\,c_e = 10b_0$'};

panel_label = {'(a)','(b)','(c)','(d)','(e)','(f)'};

figure(1); clf;

set(gcf,'Units','centimeters','Position',[2 2 30 20],'Color','w');

tl = tiledlayout(2,3,'TileSpacing','compact','Padding','compact');

for i = 1:6

    %% Read data
    a1 = readmatrix(fullfile(data_path,folders{i},'data.dat'));
    a2 = readmatrix(fullfile(data_path,folders{i},'slope_0.25.dat'));
    a3 = readmatrix(fullfile(data_path,folders{i},'slope_0.33.dat'));

    %% Create panel
    ax = nexttile(tl,i);

    hold(ax,'on');

    %% Plot
    h1 = plot(ax,a1(:,1),a1(:,2),'bo','MarkerSize',5,'LineWidth',1.2);
    h2 = plot(ax,a2(:,1),a2(:,2),'r-','LineWidth',2);
    h3 = plot(ax,a3(:,1),a3(:,2),'k-','LineWidth',2);

    %% Log-log axes
    ax.XScale = 'log';
    ax.YScale = 'log';

    %% Limits
    xlim(ax,[100 50000]);
    ylim(ax,[1 20]);

    %% Labels
    xlabel(ax,'$t~(\mathrm{sec})$','FontSize',20,'Interpreter','latex');
    ylabel(ax,'$L_e(t)/\sigma$','FontSize',20,'Interpreter','latex');

    %% Axes formatting
    set(ax,'FontSize',18,'TickLabelInterpreter','latex','LineWidth',1.8);

    ax.XMinorTick = 'on';
    ax.YMinorTick = 'on';

    box(ax,'on');
    grid(ax,'off');
    axis(ax,'square');

    %% Legend
    lg = legend(ax,[h1 h2 h3],legend_text{i},'$1/z = 1/4$','$1/z = 1/3$','Location','southeast','Interpreter','latex','FontSize',14,'Box','off');

    %% Panel label
    text(ax,-0.2,1.04,panel_label{i},'Units','normalized','FontSize',18,'FontWeight','normal','HorizontalAlignment','left','VerticalAlignment','top','Clipping','off');

end

exportgraphics(gcf, fullfile(pwd, 'FigS5.jpg'),'Resolution',600)