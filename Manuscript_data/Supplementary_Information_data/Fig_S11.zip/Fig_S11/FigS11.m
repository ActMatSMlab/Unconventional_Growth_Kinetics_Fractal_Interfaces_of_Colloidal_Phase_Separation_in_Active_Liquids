path = pwd;

a0 = readmatrix(fullfile(path, 'line_2.5_data.txt'));
a1 = readmatrix(fullfile(path, 'line_2.66_data.txt'));
a2 = readmatrix(fullfile(path, 'line_3.0_data.txt'));

figure(1);
hold on; 

h1 = plot(NaN, NaN, 'ko','MarkerSize',8,'LineWidth',2); % Black circle for the marker
h2 = plot(NaN, NaN, 'kp','MarkerSize',8,'LineWidth',2); % Black square for the marker

plot(a0(:,1), a0(:,2), '--k','linewidth',3);
plot(a1(:,1), a1(:,2), '-.k','linewidth',3);
plot(a2(:,1), a2(:,2), ':k','linewidth',3);


plotColors = colororder(colormap(turbo(200)));

for i = 1:20
    a = readmatrix(fullfile(path, sprintf('lam6.5/time_%d.txt', i)));
    plot(a(:,1), a(:,2), 'o','Color', plotColors(i*10, :),'MarkerSize',10,'linewidth',2);
    b = readmatrix(fullfile(path, sprintf('lam7/time_%d.txt', i)));
    plot(b(:,1), b(:,2), 'p','Color', plotColors(i*10, :),'MarkerSize',10,'linewidth',2);
end
plot(a1(:,1), a1(:,2), '-.k','linewidth',3);
% plot([0 60],[0 0],'--k','linewidth',2)
set(gca, 'XScale', 'log')
set(gca, 'YScale', 'log')
set(gcf,'units','centimeters','position',[0 0 20 15])
set(gca,'FontSize',22);
xlabel('$kL(t)$','FontSize',28,'interpreter','latex')
ylabel('$S(k,t)/L(t)^2$','FontSize',28,'interpreter','latex')
axis square;
box on
xlim([0.015 18]);
ylim([0.002 20]);
xticks([0.1,1,10])
yticks([0.01;0.1;1;10])
ax = gca;
ax.LineWidth = 3; 
colorbar
clim([1,60])
cbar = colorbar;
cbar.Label.String = 'Time';
cbar.Label.FontSize = 20;
legend('$\lambda = 6.5$', '$\lambda = 7$','$d+\alpha=2.5$','$d+\alpha=2.66\pm0.008$','$d+\alpha=3.0$', 'Location','southwest','interpreter','latex','Box','off');