clear; clc; close all;

path = pwd;

a0 = readmatrix(fullfile(path,'data/K_1024.dat'));
a1 = readmatrix(fullfile(path,'data/K_2048.dat'));
a2 = readmatrix(fullfile(path,'data/slope_line_t033.dat'));
a3 = readmatrix(fullfile(path,'data/slope_line_t025.dat'));

figure(1); clf; hold on;

set(gcf,'Units','centimeters','Position',[2 2 20 15],'Color','w');

h1 = plot(a0(:,1),a0(:,2),'ko','MarkerSize',7,'MarkerFaceColor','none','LineWidth',1.8);
h2 = plot(a1(:,1),a1(:,2),'rs','MarkerSize',7,'MarkerFaceColor','none','LineWidth',1.8);
h3 = plot(a2(:,1),a2(:,2),'k--','LineWidth',2.5);
h4 = plot(a3(:,1),a3(:,2),'k-.','LineWidth',2.5);

set(gca,'XScale','log','YScale','log');

xlabel('$t$','Interpreter','latex','FontSize',30);
ylabel('$L(t)$','Interpreter','latex','FontSize',30);

xlim([3 5000]);
ylim([3.8 10.5]);

xticks([10 100 1000]);
yticks([4 6 10]);

ax = gca;
ax.FontSize = 22;
ax.LineWidth = 2.5;
ax.TickLabelInterpreter = 'latex';
ax.XMinorTick = 'on';
ax.YMinorTick = 'on';

box on;
axis square;
grid off;

legend([h1 h2 h3 h4],{'$K=1024$','$K=2048$','$L(t)\sim t^{0.25}$','$L(t)\sim t^{0.33}$'},'Location','east','Interpreter','latex','FontSize',16,'Box','on');

hold off;